#!/bin/bash

# JDK 8
#export JAVA_HOME=/lib/jvm/java-1.8.0-openjdk

# JDK 11
#export JAVA_HOME=/lib/jvm/java-11-openjdk

export ROOT_DIR=$(pwd)
extra_compile_args=""
extra_run_args=""

javac_version=$($JAVA_HOME/bin/javac -version 2>&1)
if [[ $javac_version != *"1.8.0"* && $javac_version != *"1.7.0"* ]]; then
  extra_compile_args="${extra_compile_args} --add-exports java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED --add-exports jdk.jartool/sun.tools.jar=ALL-UNNAMED"
  extra_run_args="${extra_run_args} --add-opens java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED"
fi

# Cleanup
rm -rf $ROOT_DIR/bin
mkdir -p $ROOT_DIR/bin

cd $ROOT_DIR/bin

# Bootstrap
$JAVA_HOME/bin/javac -XDignore.symbol.file=true -d $ROOT_DIR/bin -cp $ROOT_DIR/src:$ROOT_DIR/src/patchingLib ${extra_compile_args} $ROOT_DIR/src/patchingLib/Bootstrapper.java
$JAVA_HOME/bin/java -cp $ROOT_DIR/bin Bootstrapper

# Debug:
# $JAVA_HOME/bin/javac -XDignore.symbol.file=true -d $ROOT_DIR/bin -cp $ROOT_DIR/src:$ROOT_DIR/src/patchingLib $ROOT_DIR/src/Main.java && $JAVA_HOME/bin/java -javaagent:redefineagent.jar -Xdebug -Xrunjdwp:transport=dt_socket,address=127.0.0.1:8000 -Dfile.encoding=UTF-8 -cp $ROOT_DIR/bin Main

# No debug:
$JAVA_HOME/bin/javac -XDignore.symbol.file=true -d $ROOT_DIR/bin -cp $ROOT_DIR/src:$ROOT_DIR/src/patchingLib ${extra_compile_args} $ROOT_DIR/src/Main.java && $JAVA_HOME/bin/java ${extra_run_args} -javaagent:redefineagent.jar -cp $ROOT_DIR/bin Main

cd $ROOT_DIR
