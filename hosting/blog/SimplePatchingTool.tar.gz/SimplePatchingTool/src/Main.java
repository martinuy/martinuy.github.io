/*
 * Copyright (c) 2019, Red Hat, Inc.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */

/*
 * @test
 * @bug 9999999
 * @requires jdk.version.major > 7
 * @library patchingLib
 * @compile -XDignore.symbol.file=true patchingLib/Bootstrapper.java
 * @run main Bootstrapper
 * @run main/othervm -javaagent:redefineagent.jar Main
 * @author Martin Balao (mbalao@redhat.com)
 */

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.net.DatagramSocket;

import jdk.internal.org.objectweb.asm.MethodVisitor;

/*
 * Patch java.net.DatagramSocket default constructor to return a fixed port.
 */

final public class Main {

    private static final class MyMethodPatcher extends ClassPatcher.MethodPatcher {

        private static Constructor<?> DatagramSocketConstructor;
        private static Method getDefaultPortMethod;

        public MyMethodPatcher(MethodVisitor mv) throws Exception {
            super(mv);
            try {
                DatagramSocketConstructor =
                        DatagramSocket.class.getDeclaredConstructor();
                getDefaultPortMethod = Hooker.class.getDeclaredMethod(
                        "getDefaultPort", int.class);
            } catch (NoSuchMethodException e) {
                e.printStackTrace();
                throw e;
            }
        }

        public void visitMethodInsn(int opcode, String owner, String name,
                String desc, boolean itf) {
            // Patch DatagramSocket() constructor
            if (getMethodBeingPatched().equals(DatagramSocketConstructor)) {
                // Patch before InetSocketAddress(port) call
                // inserting a call to Hooker.getDefaultPort that
                // will modify the port number
                if (owner.equals("java/net/InetSocketAddress") &&
                        desc.equals("(I)V")) {
                    hookerMethodInvoke(getDefaultPortMethod);
                }
            }
            super.visitMethodInsn(opcode, owner, name, desc, itf);
        }
    }

    public static void main(String[] args) throws Exception {
        printDatagramPort("BEFORE PATCHING");
        ClassPatcher.redefineClassMethods(
                "java.net.DatagramSocket",
                MyMethodPatcher.class,
                true);
        printDatagramPort("AFTER PATCHING");
    }

    private static void printDatagramPort(String msg) throws Exception {
        System.out.println("===============");
        System.out.println(msg);
        System.out.println("...............");
        System.out.println("Local Port: " +
                new DatagramSocket().getLocalPort());
    }
}

