/*
 * Copyright (c) 2019, Red Hat, Inc.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */

/*
 * @author Martin Balao (mbalao@redhat.com)
 */

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.reflect.Array;
import java.lang.reflect.Executable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import jdk.internal.org.objectweb.asm.Opcodes;

/**
 * General utilities class.
 *
 */
final public class Util {

    /**
     * Helper method to get bytes from an InputStream.
     *
     * @param is InputStream to get bytes from
     *
     * @return array of bytes read from InputStream
     *
     */
	public static byte[] getBytesFromInputStream(InputStream is) {
        try {
            try (ByteArrayOutputStream os = new ByteArrayOutputStream();) {
                byte[] buffer = new byte[0xFFFF];
                for (int len; (len = is.read(buffer)) != -1;)
                    os.write(buffer, 0, len);
                os.flush();
                return os.toByteArray();
            }
        } catch (Exception e){
            return null;
        }
    }

    /**
     * Helper method to get the signature of a method.
     *
     * Based on function from Gabriel Tofvesson.
     *
     * @param m method to get the signature
     *
     * @return Method signature string
     *
     */
    public static String getMethodSignature(Executable m) {
        String sig;
        StringBuilder sb = new StringBuilder("(");
        for(Class<?> c : m.getParameterTypes())
            sb.append((sig = Array.newInstance(c, 0).toString())
                .substring(1, sig.indexOf('@')).replace(".", "/"));
        return sb.append(')')
            .append(
                (getReturnTypeFromExecutable(m) == void.class) ? "V":
                (sig = Array.newInstance(getReturnTypeFromExecutable(m), 0).
                        toString()).substring(1, sig.indexOf('@')).replace(".", "/")
            ).toString();
    }

    private static Class<?> getReturnTypeFromExecutable(Executable m) {
        if (m instanceof Method) {
            return ((Method)m).getReturnType();
        } else {
            return void.class;
        }
    }

    /**
     * Return the ASM code depending on the JDK version.
     *
     * @return ASM opcode
     */
    public static int getASMOpcode() {
        final double javaSpecVersion = Double.parseDouble(
                System.getProperty("java.specification.version"));
        if (javaSpecVersion <= 11) {
            return getASMOpcodeReflect("ASM5");
        } else {
            return getASMOpcodeReflect("ASM7");
        }
    }

    private static int getASMOpcodeReflect(String fieldName) {
        try {
            final Field f = Opcodes.class.getDeclaredField(fieldName);
            return (int)f.getInt(Opcodes.class);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            return -1;
        }
    }
}

