/*
 * Copyright (c) 2019, Red Hat, Inc.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */

/*
 * @author Martin Balao (mbalao@redhat.com)
 */

import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Executable;
import java.lang.reflect.Method;

import jdk.internal.org.objectweb.asm.ClassReader;
import jdk.internal.org.objectweb.asm.ClassVisitor;
import jdk.internal.org.objectweb.asm.ClassWriter;
import jdk.internal.org.objectweb.asm.MethodVisitor;
import jdk.internal.org.objectweb.asm.Opcodes;

/**
 * Class to patch a method.
 *
 */
final public class ClassPatcher extends ClassVisitor {

    Class<?> classToBePatched = null;
    Class<?> methodPatcherClass = null;

    public static class MethodPatcher extends MethodVisitor {
        public static Executable STATIC_INITIALIZER_SENTINEL;
        static {
            try {
                STATIC_INITIALIZER_SENTINEL =
                        MethodPatcher.class.getDeclaredConstructor(
                                MethodVisitor.class);
            } catch (NoSuchMethodException e) {
            }
        }
        private Executable method;

        protected MethodPatcher(MethodVisitor mv) {
            super(Util.getASMOpcode(), mv);
        }

        void setMethodBeingPatched(Executable method) {
            this.method = method;
        }

        protected void hookerMethodInvoke(Method hookerMethod) {
            super.visitMethodInsn(Opcodes.INVOKESTATIC, "Bridge",
                    hookerMethod.getName(),
                    Util.getMethodSignature(hookerMethod), false);
        }

        protected Executable getMethodBeingPatched() {
            return method;
        }
    }

    private static class ClassPatcherException extends Exception {
        ClassPatcherException(String msg) {
            super(msg);
        }
    }

    /**
     * Redefine class methods.
     *
     * @param className Name of the class to be patched
     * @param methodPatcherClass Patcher class to rewrite class methods
     * @param debugDump true to dump the patched class bytecodes
     *
     */
    public static void redefineClassMethods(String className,
            Class<?> methodPatcherClass, boolean debugDump)
            throws ClassNotFoundException, ClassPatcherException {
        Class<?> cl = Class.forName(className);
        byte[] patchedClass = patchClassMethods(className, methodPatcherClass);
        if (debugDump) {
            try {
                try (FileOutputStream out = new FileOutputStream(
                        className + ".patched.class")) {
                    out.write(patchedClass);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        try {
            RedefineClassHelper.redefineClass(cl, patchedClass);
        } catch (Exception e) {
            e.printStackTrace();
            throw new ClassPatcherException(e.toString());
        }
    }

    /**
     * Patch class methods.
     *
     * @param className Name of the class to be patched
     * @param methodPatcherClass Patcher class to rewrite class methods
     *
     * @return patched class bytes
     *
     */
    public static byte[] patchClassMethods(String className,
            Class<?> methodPatcherClass)
            throws ClassNotFoundException, ClassPatcherException {
        Class<?> cl = Class.forName(className);
        InputStream classStream =
                ClassPatcher.class.getClassLoader().getResourceAsStream(
                className.replace('.', '/') + ".class");
        byte[] classBytes = Util.getBytesFromInputStream(classStream);
        ClassReader cr = new ClassReader(classBytes);
        ClassWriter cw = new ClassWriter(Util.getASMOpcode() |
                ClassWriter.COMPUTE_FRAMES);
        cr.accept(new ClassPatcher(cw, cl, methodPatcherClass), 0);
        return cw.toByteArray();
    }

	private ClassPatcher(ClassVisitor cv, Class<?> classToBePatched,
            Class<?> methodPatcherClass)
            throws ClassPatcherException {
		super(Util.getASMOpcode(), cv);
        this.classToBePatched = classToBePatched;
        this.methodPatcherClass = methodPatcherClass;
        if (!ClassPatcher.MethodPatcher.class.isAssignableFrom(methodPatcherClass)) {
            throw new ClassPatcherException("methodPatcherClass must be subclass of" +
                    " ClassPatcher::MethodPatcher");
        }
	}

	public MethodVisitor visitMethod(int access, String name, String desc,
            String signature, String[] exceptions) {
		MethodVisitor mv = super.visitMethod(access, name, desc, signature,
                exceptions);
        Executable methodBeingVisited = null;
        Executable[] classMethods = null;
        if (name.equals("<clinit>")) {
            methodBeingVisited = MethodPatcher.STATIC_INITIALIZER_SENTINEL;
        } else {
            if (name.equals("<init>")) {
                classMethods = classToBePatched.getDeclaredConstructors();
            } else {
                classMethods = classToBePatched.getDeclaredMethods();
            }
            for (Executable classMethod : classMethods) {
                if ((classMethod.getName().equals(name) || (name.equals("<init>") &&
                        classMethod.getName().equals(classToBePatched.getName()))) &&
                        Util.getMethodSignature(classMethod).equals(desc)) {
                    methodBeingVisited = classMethod;
                    break;
                }
            }
        }
	    try {
	        Constructor<?> methodPatcherClassConstructor =
	                this.methodPatcherClass.getDeclaredConstructor(
                            MethodVisitor.class);
            MethodPatcher mp = (MethodPatcher)methodPatcherClassConstructor.newInstance(
                    mv);
            mp.setMethodBeingPatched(methodBeingVisited);
	        return mp;
	    } catch (Throwable t) {
            t.printStackTrace();
	        return null;
	    }
	}
}

