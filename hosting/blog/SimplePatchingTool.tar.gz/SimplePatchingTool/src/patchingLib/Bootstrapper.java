/*
 * Copyright (c) 2019, Red Hat, Inc.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */

/*
 * @author Martin Balao (mbalao@redhat.com)
 */

import java.io.PrintWriter;
import java.io.InputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.HashMap;
import java.util.Iterator;

import jdk.internal.org.objectweb.asm.ClassReader;
import jdk.internal.org.objectweb.asm.ClassVisitor;
import jdk.internal.org.objectweb.asm.MethodVisitor;
import jdk.internal.org.objectweb.asm.Opcodes;

import com.oracle.java.testlibrary.InMemoryJavaCompiler;

public final class Bootstrapper {

    public static void main(String[] args) throws Exception {
        RedefineClassHelper.main(new String[0]);
        generateBridge();
    }

    private static void generateBridge() throws Exception {
        byte[] bridgeClassBytes = BridgeGenerator.generate();
        try (FileOutputStream out = new FileOutputStream("Bridge.class")) {
            out.write(bridgeClassBytes);
        }
        PrintWriter pw = new PrintWriter("MANIFEST_BRIDGE.MF");
        pw.println("Premain-Class: Bridge");
        pw.close();
        sun.tools.jar.Main jarTool = new sun.tools.jar.Main(System.out, System.err, "jar");
        if (!jarTool.run(new String[] { "-cmf", "MANIFEST_BRIDGE.MF", "bridge.jar",
                "Bridge.class" })) {
            throw new Exception("jar operation failed");
        }
    }

    private static final class BridgeGenerator extends ClassVisitor {
        private static Map<String,String> defaultStringValues = new HashMap<>();
        private static Map<String,String> nativeTypeNames = new HashMap<>();
        private static Pattern argTypesPattern = null;

        static {
            defaultStringValues.put("int", "0x0");
            defaultStringValues.put("long", "0x0L");
            defaultStringValues.put("byte[]", "null");
            defaultStringValues.put("Object", "null");
            defaultStringValues.put("boolean", "false");

            nativeTypeNames.put("I", "int");
            nativeTypeNames.put("J", "long");
            nativeTypeNames.put("[B", "byte[]");
            nativeTypeNames.put("L", "Object");
            nativeTypeNames.put("V", "void");
            nativeTypeNames.put("Z", "boolean");

            StringBuffer argTypesPatternReg = new StringBuffer();
            Iterator<String> it = nativeTypeNames.keySet().iterator();
            while (it.hasNext()) {
                argTypesPatternReg.append(escapeRegexChars(it.next()));
                if (it.hasNext()) {
                    argTypesPatternReg.append("|");
                }
            }
            argTypesPattern = Pattern.compile("(" + argTypesPatternReg.toString() + ").*",
                    Pattern.DOTALL);
        }

        private static String BridgeSrc = "";

        private static String escapeRegexChars(String regex) {
            return regex.replace("[", "\\[");
        }

        public static byte[] generate() throws Exception {
            generateBridgeSrcPrologue();
            InputStream classStream = null;
            if (System.getProperty("test.class.path") != null &&
                    System.getProperty("test.class.path").isEmpty() == false) {
                String[] classFilePaths =
                        System.getProperty("test.class.path").split(File.pathSeparator);
                for (String classFilePath : classFilePaths) {
                    try {
                        classStream = new FileInputStream(
                                classFilePath + File.separator +
                                        (Hooker.class.getName()).replace('.', '/') + ".class");
                    } catch (Exception e) {
                    }
                    if (classStream != null) {
                        break;
                    }
                }
            } else {
                classStream = ClassLoader.getSystemClassLoader().getResourceAsStream(
                        (Hooker.class.getName()).replace('.', '/') + ".class");
            }
            byte[] classBytes = Util.getBytesFromInputStream(classStream);
            ClassReader cr = new ClassReader(classBytes);
            cr.accept(new BridgeGenerator(), 0);
            generateBridgeSrcEpilogue();
            return InMemoryJavaCompiler.compile("Bridge", BridgeSrc);
        }

        private BridgeGenerator(){
            super(Opcodes.ASM5, null);
        }

        public MethodVisitor visitMethod(int access, String name, String desc,
                String signature, String[] exceptions) {
            generateBridgeSrcMethod(name, desc);
            return super.visitMethod(access, name, desc, signature, exceptions);
        }

        private static void generateBridgeSrcMethod(String methodName, String methodSignature) {
            if (!methodName.equals("<init>") &&
                    !methodName.equals("<clinit>")) {
                String[] argsWithAndWithoutTypes = getArgs(methodSignature);
                String argsWithTypes = argsWithAndWithoutTypes[0];
                String args = argsWithAndWithoutTypes[1];
                if (args.length() > 0) {
                    args = ", "+args;
                }
                String returnTypeString = getReturnTypeString(methodSignature);
                String returnStmt = "";
                String defaultReturnStmt = "";
                if (!returnTypeString.equals("void")) {
                    returnStmt = "return ("+returnTypeString +")";
                    defaultReturnStmt = "return " +
                            defaultStringValues.get(returnTypeString) +";";
                }
                BridgeSrc +=
                        "public static "+ returnTypeString +" "+ methodName +"("+ argsWithTypes +") {\n"+
                        "    try {\n" +
                        "        Method m = HookerClassMethods.get(\""+ methodName +"\");\n" +
                        "        " + returnStmt + "m.invoke(HookerClass"+ args +");\n" +
                        "    } catch(Exception e) { e.printStackTrace(); }\n" +
                        "    " + defaultReturnStmt +"\n"+
                        "}\n";
            }
        }

        private static String[] getArgs(String methodSignature) {
            String args = "";
            String argsWithTypes = "";
            int argNumber = 0;
            int startArgsPos = methodSignature.indexOf("(") + 1;
            int endArgsPos = methodSignature.indexOf(")") - 1;
            for(int i = 0; i <= (endArgsPos - startArgsPos); i++) {
                args += "arg"+argNumber;
                Matcher argMatcher = argTypesPattern.matcher(
                        methodSignature.subSequence(startArgsPos + i,
                                methodSignature.length()));
                if (!argMatcher.matches()) {
                    return null;
                }
                String typeName = argMatcher.group(1);
                i += typeName.length() - 1;
                argsWithTypes += nativeTypeNames.get(typeName) + " arg"+argNumber;
                if (typeName.equals("L")) {
                    i = methodSignature.indexOf(';', startArgsPos + i) - startArgsPos;
                }
                argNumber++;
                if (i+1 <= (endArgsPos - startArgsPos)) {
                    args += ", ";
                    argsWithTypes += ", ";
                }
            }
            return new String[]{argsWithTypes, args};
        }

        private static String getReturnTypeString(String methodSignature) {
            Pattern signaturePattern = Pattern.compile("\\(.*\\)(.*)",
                    Pattern.DOTALL);
            Matcher signatureMatcher = signaturePattern.matcher(methodSignature);
            if (signatureMatcher.matches()) {
                String returnType = signatureMatcher.group(1);
                if (returnType.startsWith("L")) {
                    returnType = "L";
                }
                return nativeTypeNames.get(returnType);
            }
            return null;
        }

        private static void generateBridgeSrcPrologue() {
            BridgeSrc +=
                    "import java.lang.reflect.Method;\n" +
                    "import java.util.HashMap;\n" +
                    "import java.util.Map;\n" +
                    "public final class Bridge {\n" +
                    "    private static Class<?> HookerClass;\n" +
                    "    private static Map<String, Method> HookerClassMethods;\n" +
                    "    static {\n" +
                    "        try {\n" +
                    "            HookerClass = ClassLoader.getSystemClassLoader().loadClass(\"Hooker\");\n" +
                    "            HookerClassMethods = new HashMap<String, Method>();\n" +
                    "            Method[] ms = HookerClass.getDeclaredMethods();\n" +
                    "            for (Method m : ms) {\n" +
                    "                HookerClassMethods.put(m.getName(), m);\n" +
                    "            }\n" +
                    "        } catch (Exception e) {\n" +
                    "    }\n" +
                    "}\n";
        }

        private static void generateBridgeSrcEpilogue() {
            BridgeSrc +=
                    "}";
        }
    }
}

