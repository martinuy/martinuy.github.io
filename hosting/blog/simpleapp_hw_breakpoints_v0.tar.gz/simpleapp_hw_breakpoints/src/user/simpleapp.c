/*
 *   Martin Balao (martin.uy) - Copyright 2020
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include "simplelib.h"
#include "simplemodule.h"

int main(void) {
    int ret = -1;
    int simplemodule_fd = -1;
    printf("main - begin\n");

    if (load_module() == SLIB_ERROR) {
        goto error;
    }

    while((simplemodule_fd = open(SAMODULE_DEVICE_PATH, O_RDWR)) == -1 && errno == EINTR);
    if (simplemodule_fd < 0) {
        goto error;
    }

    if (ioctl(simplemodule_fd, SAMODULE_IOCTL_TEST, 0UL) != SAMODULE_SUCCESS) {
        goto error;
    }

    goto success;
error:
    printf("main - end error\n");
    ret = -1;
    goto cleanup;
success:
    printf("main - end success\n");
    ret = 0;
    goto cleanup;
cleanup:
    if (simplemodule_fd != -1) {
        close(simplemodule_fd);
    }
    unload_module();
    return ret;
}

