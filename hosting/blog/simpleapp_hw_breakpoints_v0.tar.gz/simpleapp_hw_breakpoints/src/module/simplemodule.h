/*
 *   Martin Balao (martin.uy) - Copyright 2020
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef SIMPLEMODULE_H
#define SIMPLEMODULE_H

#ifdef SAMODULE_FROM_USER
#include <unistd.h>
#else
#include <linux/unistd.h>
#endif // SAMODULE_FROM_USER

#define SAMODULE_NAME "simplemodule"
#define SAMODULE_IMAGE SAMODULE_NAME".ko"
#define SAMODULE_DEVICE_PATH "/dev/"SAMODULE_NAME"_dev"

#define SAMODULE_SUCCESS 0L
#define SAMODULE_ERROR -1L



// IOCTLs
#define SAMODULE_IOCTL_TEST 1U

#endif // SIMPLEMODULE_H
