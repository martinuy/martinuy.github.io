/*
 *   Martin Balao (martin.uy) - Copyright 2020
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <linux/capability.h>
#include <linux/cdev.h>
#include <linux/delay.h>
#include <linux/device.h>
#include <linux/err.h>
#include <linux/fs.h>
#include <linux/hw_breakpoint.h>
#include <linux/kallsyms.h>
#include <linux/kernel.h>
#include <linux/list.h>
#include <linux/module.h>
#include <linux/mutex.h>
#include <linux/sched.h>
#include <linux/sched/signal.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <linux/syscalls.h>
#include <linux/unistd.h>

#include "simplemodule.h"

/////////////////////
//     Defines     //
/////////////////////
#define SM_PRINTF(args...) printk("SimpleModule: " args)

/////////////////////////
// Function prototypes //
/////////////////////////
extern long asm_test_function(void);
static long unlocked_ioctl(struct file* f, unsigned int cmd, unsigned long arg);

///////////////////////
// Global variables  //
///////////////////////
static dev_t simplemodule_devt = -1;
static struct cdev simplemodule_cdev;
static struct class* simplemodule_class = NULL;
static struct device* simplemodule_device = NULL;
static DEFINE_MUTEX(global_lock);
static const struct file_operations fops = {
    .unlocked_ioctl = unlocked_ioctl,
    .owner = THIS_MODULE,
};

/////////////////////
//    Functions    //
/////////////////////
static void bp_handler(struct perf_event* pe, struct perf_sample_data* psd, struct pt_regs* regs) {
    SM_PRINTF("bp_handler - begin");
    SM_PRINTF("bp_handler - IP: 0x%lx\n", regs->ip);
    SM_PRINTF("bp_handler - end");
}

static long unlocked_ioctl(struct file* f, unsigned int cmd, unsigned long arg) {
    long ret_val = SAMODULE_ERROR;
    struct perf_event_attr attr;
    struct perf_event** bps;

    mutex_lock(&global_lock);

    switch(cmd) {
    case SAMODULE_IOCTL_TEST:
        SM_PRINTF("SAMODULE_IOCTL_TEST\n");

        hw_breakpoint_init(&attr);
        attr.bp_addr = (unsigned long)asm_test_function();
        attr.bp_len = HW_BREAKPOINT_LEN_8;
        attr.bp_type = HW_BREAKPOINT_X;
        bps = register_wide_hw_breakpoint(&attr, bp_handler, NULL);

        SM_PRINTF("asm_test_function() = %ld\n", asm_test_function());

        unregister_wide_hw_breakpoint(bps);

        break;
    }
    ret_val = SAMODULE_SUCCESS;
    goto cleanup;

cleanup:
    mutex_unlock(&global_lock);
    return ret_val;
}

static void __exit simplemodule_cleanup(void) {
    SM_PRINTF("simplemodule_cleanup - begin\n");
    if (simplemodule_device != NULL && simplemodule_class != NULL && simplemodule_devt != -1) {
        device_destroy(simplemodule_class, simplemodule_devt);
    }
    if (simplemodule_class != NULL) {
        class_destroy(simplemodule_class);
    }
    if (simplemodule_devt != -1) {
        unregister_chrdev_region(simplemodule_devt, 1);
    }
    SM_PRINTF("simplemodule_cleanup - end\n");
}

static int __init simplemodule_init(void) {
    SM_PRINTF("simplemodule_init - begin\n");

    if (alloc_chrdev_region(&simplemodule_devt, 0, 1, SAMODULE_NAME "_proc") != 0) {
        goto error;
    }
    SM_PRINTF("Device major: %d\n", MAJOR(simplemodule_devt));
    SM_PRINTF("Device minor: %d\n", MINOR(simplemodule_devt));

    if ((simplemodule_class = class_create(THIS_MODULE, SAMODULE_NAME "_sys")) == NULL) {
        goto error;
    }

    if ((simplemodule_device = device_create(simplemodule_class, NULL, simplemodule_devt, NULL, SAMODULE_NAME "_dev")) == NULL) {
        goto error;
    }

    cdev_init(&simplemodule_cdev, &fops);

    if (cdev_add(&simplemodule_cdev, simplemodule_devt, 1) == -1) {
        goto error;
    }

    goto success;

error:
    SM_PRINTF("simplemodule_init - end error\n");
    return SAMODULE_ERROR;

success:
    SM_PRINTF("simplemodule_init - end success\n");
    return SAMODULE_SUCCESS;
}

module_init(simplemodule_init);
module_exit(simplemodule_cleanup);
MODULE_LICENSE("GPL");
