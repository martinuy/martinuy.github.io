//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>
#include <Windows.h>
void main(void) {
	if (IsDebuggerPresent()) {
		printf("Process being debugged\n");
	} else {
		printf("Process NOT debugged\n");
	}
}
