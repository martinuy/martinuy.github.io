//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#define __NR_WRITE 4

#define _syscall3(name,arg1,arg2,arg3)  \
do {                                    \
    __asm__ __volatile__                \
    (                                   \
        "int $0x80\n\t"                 \
        : /* no output */               \
        : "a"(__NR_##name),             \
          "b"(arg1),                    \
          "c"(arg2),                    \
          "d"(arg3)                     \
    );                                  \
} while(0);

#define _sys_write(fd, buf, count) _syscall3(WRITE, fd, buf, count)

#include <dlfcn.h>

int main(){
    int a;
    unsigned int b = 0;
    for(a = 0; a < 10; a++){
        b = b++ | (~a) & 0xF0;
    }
    char c[6] = { 'h', 'o', 'l', 'a', '\n', 0x0};
    _sys_write(0, c, sizeof(c));
    void* dlsym_ptr = (void*)0;
    if(dlsym_ptr != (void*)0){
        ((void*(*)(void*, const char*))dlsym_ptr)(0, "getaddrinfo");
    }
    return b;
}
