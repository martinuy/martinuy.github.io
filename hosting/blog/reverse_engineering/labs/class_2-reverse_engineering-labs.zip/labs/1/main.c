//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>
#include <Windows.h>

extern void f_a(void);

volatile int var_a;

const char* t = "hola";

int main(){
	var_a = 1;
	f_a();
	HMODULE test_dll_handle = LoadLibrary("test.dll");
	if (test_dll_handle != NULL){
		int(*test_function_ptr)() = (int(*)())GetProcAddress(test_dll_handle, "test");
		if(test_function_ptr != NULL){
			int ret = test_function_ptr();
			printf("Return: %d\n", ret);
		}
	}
	return 0;
}
