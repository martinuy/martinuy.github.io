//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <errno.h>
#include <linux/capability.h>
#include <netinet/in.h>
#include <stdio.h>
#include <string.h>
#include <sys/capability.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#define MEMORY_SIZE 1024

int main() {
    int ret = -1;
    cap_t process_capabilities = NULL;
    int socket_fd = -1;
    cap_value_t caps[] = { CAP_NET_RAW };
    printf("Start\n");

    printf("Creating socket...\n");
    socket_fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
    if (socket_fd == -1) {
        goto error;
    }
    printf("socket_fd: %d\n", socket_fd);
    close(socket_fd);
    socket_fd = -1;

    printf("Dropping CAP_NET_RAW capability\n");
    process_capabilities = cap_get_proc();
    if (process_capabilities == NULL) {
        goto error;
    }
    if (cap_set_flag(process_capabilities, CAP_EFFECTIVE, sizeof(caps) / sizeof(cap_value_t), caps, CAP_CLEAR) == -1) {
        goto error;
    }
    if (cap_set_flag(process_capabilities, CAP_PERMITTED, sizeof(caps) / sizeof(cap_value_t), caps, CAP_CLEAR) == -1) {
        goto error;
    }
    if (cap_set_flag(process_capabilities, CAP_INHERITABLE, sizeof(caps) / sizeof(cap_value_t), caps, CAP_CLEAR) == -1) {
        goto error;
    }
    if (cap_set_proc(process_capabilities) == -1) {
        goto error;
    }

    printf("Creating socket...\n");
    socket_fd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
    if (socket_fd == -1) {
        printf("Socket couldn't be created\n");
    } else {
        goto error;
    }

    printf("Trying to re-acquire CAP_NET_RAW capability\n");

    if (process_capabilities == NULL) {
        goto error;
    }
    if (cap_set_flag(process_capabilities, CAP_EFFECTIVE, sizeof(caps) / sizeof(cap_value_t), caps, CAP_SET) == -1) {
        goto error;
    }
    if (cap_set_flag(process_capabilities, CAP_PERMITTED, sizeof(caps) / sizeof(cap_value_t), caps, CAP_SET) == -1) {
        goto error;
    }
    if (cap_set_flag(process_capabilities, CAP_INHERITABLE, sizeof(caps) / sizeof(cap_value_t), caps, CAP_SET) == -1) {
        goto error;
    }
    if (cap_set_proc(process_capabilities) != -1) {
        printf("Error 2\n");
        goto error;
    }
    printf("Capability couldn't be re-acquired. Error: %s\n", strerror(errno));

    goto success;
error:
    ret = -1;
    printf("Error occurred\n");
    goto cleanup;
success:
    ret = 0;
    printf("Finished\n");
    goto cleanup;
cleanup:
    if (process_capabilities != NULL) {
        cap_free(process_capabilities);
    }
    if (socket_fd != -1) {
        close(socket_fd);
    }
    return ret;
}
