#!/bin/bash

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

rm -rf bin
mkdir bin

gcc -o bin/main src/main.c -lcap

chmod +x bin/main

sudo setcap cap_net_raw=ep ./bin/main
getcap ./bin/main

./bin/main
