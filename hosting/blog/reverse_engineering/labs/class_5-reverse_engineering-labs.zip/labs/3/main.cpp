//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <Windows.h>
#include <stdio.h>
#include <Objbase.h>
#include <Exdisp.h>
#include <OleAuto.h>
#include <Unknwn.h>

int main(void) {

	if (SUCCEEDED(OleInitialize(NULL))) {
		IUnknown* pObjUnknown = NULL;
		IWebBrowser2* pObjBrowser2 = NULL;

		if (SUCCEEDED(CoCreateInstance(CLSID_InternetExplorer, NULL, CLSCTX_LOCAL_SERVER, 
						   IID_IUnknown, reinterpret_cast<void**>(&pObjUnknown))) && pObjUnknown) {
			
			printf("Succeeded creating COM object\n");
			printf("Obj as IUnknown: %p\n", pObjUnknown);
			printf("Obj IUnknown vtable: %p\n", *reinterpret_cast<void**>(pObjUnknown));
			
			if (SUCCEEDED(pObjUnknown->QueryInterface(IID_IWebBrowser2, reinterpret_cast<void**>(&pObjBrowser2)))) {
			
				printf("Obj as IWebBrowser2: %p\n", pObjBrowser2);
				printf("Obj IWebBrowser2 vtable: %p\n", *reinterpret_cast<void**>(pObjBrowser2));
				
				VARIANT vEmpty;
				VariantInit(&vEmpty);
				BSTR bstrURL = SysAllocString(L"http://google.com");

				HRESULT hr = pObjBrowser2->Navigate(bstrURL, &vEmpty, &vEmpty, &vEmpty, &vEmpty);
				if (SUCCEEDED(hr)) {
					pObjBrowser2->put_Visible(VARIANT_TRUE);
				} else {
					pObjBrowser2->Quit();
				}

				SysFreeString(bstrURL);
			}
			pObjUnknown->Release();
		}
		OleUninitialize();
    }
	return 0;
}
