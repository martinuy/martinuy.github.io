//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <cstdlib>
#include <stdio.h>
#include <Windows.h>


int main(int argc, char** argv)
{
	HANDLE process_to_inject_handle = NULL;
	LPVOID executable_code_address_on_remote_process = NULL;
	constexpr SIZE_T executable_code_size = 1024;
	const char executable_code_buffer[executable_code_size] = { 0xcc, 0xc3}; // INT3, RET
	bool injection_succeed = false;

	if (argc == 2) {
		const unsigned int process_to_inject_pid = static_cast<unsigned int>(atoi(argv[1]));
		process_to_inject_handle = OpenProcess(PROCESS_ALL_ACCESS, false, static_cast<DWORD>(process_to_inject_pid));
		if (process_to_inject_handle != NULL) {
			executable_code_address_on_remote_process = VirtualAllocEx(process_to_inject_handle, NULL, executable_code_size, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
			printf("Allocated memory %p\n", executable_code_address_on_remote_process);
			if(executable_code_address_on_remote_process != NULL){
				SIZE_T executable_code_bytes_written = 0;
				if (WriteProcessMemory(process_to_inject_handle, executable_code_address_on_remote_process, executable_code_buffer, executable_code_size, &executable_code_bytes_written) == TRUE && executable_code_bytes_written == executable_code_size) {
					DWORD new_thread_id = 0;
					if (CreateRemoteThread(process_to_inject_handle, NULL, 0, static_cast<LPTHREAD_START_ROUTINE>(executable_code_address_on_remote_process), NULL, 0, &new_thread_id) != NULL) {
						injection_succeed = true;
						printf("Injection succeeded!\n");
						printf("New thread id: %d\n", new_thread_id);
					} else {
						printf("Injection last error: %d\n", GetLastError());
					}

				}
			}
			

		}
	}
cleanup:

	if (injection_succeed == false && executable_code_address_on_remote_process != NULL) {
		VirtualFreeEx(process_to_inject_handle, executable_code_address_on_remote_process, 0, MEM_RELEASE);
		executable_code_address_on_remote_process = NULL;
	}

	if (process_to_inject_handle != NULL) {
		CloseHandle(process_to_inject_handle);
		process_to_inject_handle = NULL;
	}
    return 0;
}

