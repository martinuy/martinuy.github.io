//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <AccCtrl.h>
#include <Aclapi.h>
#include <stdio.h>
#include <Windows.h>

int main() {
	int ret = -1;
	unsigned int i = 0;
	HANDLE process_token = NULL;
	DWORD returned_length = 0x0;
	DWORD token_session_id = 0x0;
	PTOKEN_USER token_user = NULL;
	LPTSTR user_sid_as_string = NULL;
	PTOKEN_PRIVILEGES token_privileges = NULL;
	HMODULE h_advapi32_module = NULL;
	BOOL(*ConvertSidToStringSid)(PSID, LPTSTR *) = NULL;
	LUID_AND_ATTRIBUTES privilege;
	LPTSTR privilege_name = NULL;
	PSID securable_object_owner = NULL;
	PSECURITY_DESCRIPTOR securable_object_security_descriptor = NULL;

	h_advapi32_module = LoadLibrary("Advapi32.dll");
	if (h_advapi32_module == NULL) {
		goto error;
	}

	ConvertSidToStringSid = (BOOL(*)(PSID, LPTSTR *))GetProcAddress(h_advapi32_module, "ConvertSidToStringSidA");
	if (ConvertSidToStringSid == NULL) {
		goto error;
	}

	printf("Getting process token (OpenProcessToken):\n");
	if (OpenProcessToken(GetCurrentProcess(), TOKEN_ALL_ACCESS, &process_token) == FALSE) {
		goto error;
	}
	printf("%p\n", process_token);

	printf("Getting process token session ID (GetTokenInformation - TokenSessionId):\n");
	if (GetTokenInformation(process_token, TokenSessionId, &token_session_id, sizeof(DWORD), &returned_length) == FALSE) {
		goto error;
	}
	printf("%d\n", token_session_id);

	printf("Getting process token user (GetTokenInformation - TokenUser):\n");
	if (GetTokenInformation(process_token, TokenUser, token_user, 0, &returned_length) == FALSE && GetLastError() != 122) {
		goto error;
	}
	token_user = (PTOKEN_USER)malloc(returned_length);
	memset(token_user, 0, returned_length);
	if (GetTokenInformation(process_token, TokenUser, token_user, returned_length, &returned_length) == FALSE) {
		goto error;
	}

	printf("token_user.User.Sid: %p\n", token_user->User.Sid);
	if (ConvertSidToStringSid(token_user->User.Sid, &user_sid_as_string) == FALSE) {
		goto error;
	}
	printf("%s\n", user_sid_as_string);

	printf("Getting process token user (GetTokenInformation - TokenPrivileges):\n");
	if (GetTokenInformation(process_token, TokenPrivileges, token_privileges, 0, &returned_length) == FALSE && GetLastError() != 122) {
		goto error;
	}
	token_privileges = (PTOKEN_PRIVILEGES)malloc(returned_length);
	memset(token_privileges, 0, returned_length);
	if (GetTokenInformation(process_token, TokenPrivileges, token_privileges, returned_length, &returned_length) == FALSE) {
		goto error;
	}
	printf("Privileges count: %d\n", token_privileges->PrivilegeCount);
	for (i = 0; i < token_privileges->PrivilegeCount; i++) {
		returned_length = 0;
		if (LookupPrivilegeName(NULL, &(token_privileges->Privileges[i].Luid), NULL, &returned_length) == FALSE && GetLastError() != 122) {
			goto error;
		}
		if (privilege_name != NULL) {
			free(privilege_name);
			privilege_name = NULL;
		}
		privilege_name = malloc(returned_length + 1);
		memset(privilege_name, 0, returned_length + 1);
		if (LookupPrivilegeName(NULL, &(token_privileges->Privileges[i].Luid), privilege_name, &returned_length) == FALSE) {
			goto error;
		}
		printf("privilege_name: %s\n", privilege_name);
	}

	printf("Getting user32.dll securable object information (GetNamedSecurityInfo - OWNER_SECURITY_INFORMATION):\n");
	if (GetNamedSecurityInfo("C:\\Windows\\System32\\user32.dll", SE_FILE_OBJECT, OWNER_SECURITY_INFORMATION, &securable_object_owner, NULL, NULL, NULL, &securable_object_security_descriptor) != 0x0) {
		goto error;
	}
	printf("token_user.User.Sid: %p\n", securable_object_owner);
	if (user_sid_as_string != NULL) {
		LocalFree(user_sid_as_string);
		user_sid_as_string = NULL;
	}
	if (ConvertSidToStringSid(securable_object_owner, &user_sid_as_string) == FALSE) {
		goto error;
	}
	printf("%s\n", user_sid_as_string);

	goto success;
error:
	printf("Error: %d\n", GetLastError());
	ret = -1;
	goto cleanup;
success:
	printf("Finished\n");
    ret = 0;
	goto cleanup;
cleanup:
	if (user_sid_as_string != NULL) {
		LocalFree(user_sid_as_string);
	}
	if (token_user != NULL) {
		free(token_user);
	}
	if (token_privileges != NULL) {
		free(token_privileges);
	}
	if (privilege_name != NULL) {
		free(privilege_name);
	}
	if (securable_object_security_descriptor != NULL) {
		LocalFree(securable_object_security_descriptor);
	}
	if (h_advapi32_module != NULL) {
		CloseHandle(h_advapi32_module);
	}
	if (process_token != NULL) {
		CloseHandle(process_token);
	}
	return ret;
}
