//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdlib.h>
#include <sys/mman.h>
#include <stdio.h>
#include <pthread.h>

int main(){
    pthread_t t;
    pthread_create(&t, NULL, (void*(*)(void*))0x41414141, 0);
}
