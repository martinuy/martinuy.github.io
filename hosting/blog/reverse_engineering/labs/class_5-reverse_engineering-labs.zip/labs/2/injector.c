//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

/*
    Linux Process Injector (ptrace)
    v. 0.1

    Run as... 
            To inject a real target: 
                ./injector <target-PID>
            To fork and inject child (debugging purposes):
                ./injector

    Injects 64 bits processes. Requirement: target process must have libc mapped.

    Compile the injector in 64 bits (link against libdl & libpthread). 
*/

#define _GNU_SOURCE

#include <dlfcn.h>
#include <errno.h>
#include <semaphore.h>
#include <sched.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/user.h>
#include <sys/wait.h>
#include <unistd.h>

// Global variables

struct sigaction sigchld_action;                        // Structure for child (SIGCHLD) signal handler
pid_t process_to_inject_pid;                            // Target process PID
typedef enum events_t { NONE, STOP } events_t;          // Types of events information to synchronize with the signal handler
events_t process_to_inject_notification_event = NONE;   // Signal handler synchronization information
sem_t process_to_inject_notify_event_semaphore;         // Signal handler synchronization event
void* mmap_in_target = NULL;                            // mmap function location in the target process

// Child (SIGCHLD) signal handler
// Tracee events will be received here by the tracer process
void sigchld_signal_handler(int signal, siginfo_t* info, void* context){
    int wait_pid_status = 0;
    pid_t p = 0;
    bool notify_event_on_process_to_inject = false;
    while(true){
        // Signal coalescing: multiple signals, one call to the handler. We need to unpack.
        while((p = waitpid(-1, &wait_pid_status, WNOHANG)) == -1 && errno == EINTR);
        if(p <= 0){
            break;
        }
        if(p == process_to_inject_pid){
            notify_event_on_process_to_inject = true;
            int status = 0; // Not used, for information purposes only
            if(WIFSTOPPED(wait_pid_status) != 0){
                status = WSTOPSIG(wait_pid_status);
                process_to_inject_notification_event = STOP;
            }
            if(WIFEXITED(wait_pid_status) != 0){
                status = WEXITSTATUS(wait_pid_status);
            }
            if(WIFSIGNALED(wait_pid_status) != 0){
                status = WTERMSIG(wait_pid_status);
            }         
        }
    }

    if(notify_event_on_process_to_inject == true){
        // Notify the debugger a new event
        if(sem_post(&process_to_inject_notify_event_semaphore) == -1){
            goto error;
        }
    }

error:
    return;
}

static bool call_function_on_target(void* function_to_call_on_target, struct user_regs_struct* regs){
    bool call_successful = false;
    long ret = 0;

    regs->rsp = (regs->rsp - 16) & 0xFFFFFFFFFFFFFF00; // Make space & align the stack to 16 bytes

    regs->rsp = regs->rsp - 8;
    // Set the return address to 0x0
    if(ptrace (PTRACE_POKEDATA, process_to_inject_pid, regs->rsp, 0) == -1){
        goto error;
    }
    
    printf("This thread is executing: %p\n", regs->rip);
    regs->rip = (long)function_to_call_on_target;

    if(ptrace(PTRACE_SETREGS, process_to_inject_pid, NULL, regs) == -1){
        goto error;
    }

    process_to_inject_notification_event = NONE;
    if(ptrace(PTRACE_CONT, process_to_inject_pid, NULL, 0) == -1){
        goto error;
    }
    // Wait for stop
    while(process_to_inject_notification_event != STOP){
        while((ret = sem_wait(&process_to_inject_notify_event_semaphore)) == -1 && errno == EINTR);
        if(ret == -1){
            goto error;
        }
    }

    printf("Process has stopped\n");
    if(ptrace(PTRACE_GETREGS, process_to_inject_pid, NULL, regs) == -1){
        goto error;
    }
    printf("This thread is executing: %p\n", regs->rip);

    call_successful = true;

error:
    return call_successful;
}

static bool allocate_memory_on_target(long memory_size, struct user_regs_struct* regs, void** allocated_buffer_ptr) {
    bool allocation_successful = false;
    long ret = false;
    if (memory_size <= 0) {
        goto error;
    }

    // Set mmap parameters
    regs->rdi = 0x0;
    regs->rsi = memory_size;
    regs->rdx = 0x6;
    regs->rcx = 0x22;
    regs->r8 = 0xFFFFFFFF;
    regs->r9 = 0x0;
    
    if(call_function_on_target(mmap_in_target, regs) == false){
        goto error;
    }
    
    if(regs->rax == -1){
        goto error;
    }
    *allocated_buffer_ptr = (void*)regs->rax;    
    printf("Allocated memory: %p\n", *allocated_buffer_ptr);
    allocation_successful = true;

error:
    return allocation_successful;
}

int main(int argc, char** argv){
    long ret = 0;
    FILE* target_process_maps = NULL;
    bool target_process_attached = false;

    if(sem_init(&process_to_inject_notify_event_semaphore, 0, 0) != 0){
        goto error;
    }

    if(argc == 2){
        // Process to inject may be received by parameter
        process_to_inject_pid = (pid_t)atoi(argv[1]);
    } else {
        // If no process to inject is received by parameter, fork and inject the child.
        pid_t child = fork();        
        if(child == 0){
            // Child will be doing an infinte loop
            while(true){
                sleep(2);
            }
        }
        process_to_inject_pid = child;
    }

    printf("Target PID %d\n", process_to_inject_pid);
  
    // Get function offsets (assumming the target process will use the same libc library than the injector)
    void* const clone_ptr = dlsym(RTLD_DEFAULT, "__clone");
    void* const mmap_ptr = dlsym(RTLD_DEFAULT, "mmap");
    if (clone_ptr == NULL || mmap_ptr == NULL){
        goto error;
    }
    Dl_info mmap_info = { 0x0 };
    if (dladdr(mmap_ptr, &mmap_info) == 0){
        goto error;
    }
    void* const injector_libc_base_address = mmap_info.dli_fbase;
    void* const injector_mmap_address = mmap_info.dli_saddr;
    if(injector_libc_base_address == NULL || injector_mmap_address == NULL){
        goto error;
    }
    const unsigned long long mmap_offset = (unsigned long long)(injector_mmap_address - injector_libc_base_address);
    const unsigned long long clone_offset = (unsigned long long)(clone_ptr - injector_libc_base_address);
    printf("injector libc base address: %p\n", injector_libc_base_address);
    printf("injector mmap address: %p\n", injector_mmap_address);
    printf("mmap offset: %p\n", mmap_offset);
    printf("clone offset: %p\n", clone_offset);

    // Get libc base address on the target process
    char target_process_pid_as_string[25] = {0x0}; 
    ret = snprintf(target_process_pid_as_string, sizeof(target_process_pid_as_string), "%d", process_to_inject_pid);  
    if (ret >= sizeof(target_process_pid_as_string) || ret < 0){
        // No room for the target PID or an error occurred
        goto error;
    }
    char target_process_maps_path[100] = {0x0};
    size_t target_process_maps_path_remaining_size = sizeof(target_process_maps_path);
    const char proc_path[] = "/proc/";
    const char maps_path[] = "/maps";
    const size_t target_process_pid_as_string_size = strlen(target_process_pid_as_string);
    target_process_maps_path_remaining_size -= 1; // Null character
    if(sizeof(proc_path) - 1 > target_process_maps_path_remaining_size){
        goto error;
    }
    target_process_maps_path_remaining_size -= (sizeof(proc_path) - 1);
    strcat(target_process_maps_path, proc_path);    
    if(target_process_pid_as_string_size > target_process_maps_path_remaining_size){
        goto error;
    }
    target_process_maps_path_remaining_size -= target_process_pid_as_string_size;
    strcat(target_process_maps_path, target_process_pid_as_string);
    if(sizeof(maps_path) - 1 > target_process_maps_path_remaining_size){
        goto error;
    }
    target_process_maps_path_remaining_size -= (sizeof(maps_path) - 1);
    strcat(target_process_maps_path, maps_path);

    printf("target_process_maps_path: %s\n", target_process_maps_path);

    target_process_maps = fopen(target_process_maps_path, "r");
    char read_buffer_line[256] = {0x0};
    unsigned int read_buffer_line_element = 0;
    bool continue_reading = true;
    char base_address_as_string[25] = {0x0};
    void* libc_base_address_in_target = 0;
    while(continue_reading){
        char read_char = 0;
        if (fread(&read_char, 1, 1, target_process_maps) != 1){
            continue_reading = false;
        }

        if(read_char == '\n' || continue_reading == false){
            // Analyze current line
            if(strstr(read_buffer_line, "libc") != NULL){
                printf("Line has libc string\n");
                int i = 0;
                while(i < sizeof(base_address_as_string) - 1 && read_buffer_line[i] != '-'){
                    base_address_as_string[i] = read_buffer_line[i];
                    i++;
                }
                if(read_buffer_line[i] != '-'){
                    goto error;
                }
                sscanf(base_address_as_string, "%p", &libc_base_address_in_target);
                break;
            }
        }

        if(continue_reading == false){
            break;
        }

        if(read_char == '\n'){
            memset(read_buffer_line, 0, sizeof(read_buffer_line));
            read_buffer_line_element = 0;
        } else {
            if(read_buffer_line_element < sizeof(read_buffer_line) - 1){
                read_buffer_line[read_buffer_line_element++] = read_char;
            } else {
                // No room in the buffer line
                goto error;
            }
        }
    }
    printf("Libc base address in target: %p\n", libc_base_address_in_target);
    mmap_in_target = (void*)((char*)libc_base_address_in_target + mmap_offset);
    void* const clone_in_target = (void*)((char*)libc_base_address_in_target + clone_offset);
    printf("mmap in target: %p\n", mmap_in_target);
    printf("clone in target: %p\n", clone_in_target);

    //////////////////////////////
    // Debug the target process //
    //////////////////////////////

    // Install the child signal handler
    memset(&sigchld_action, 0, sizeof(sigchld_action));
    sigchld_action.sa_sigaction = &sigchld_signal_handler;
    if(sigemptyset(&(sigchld_action.sa_mask)) == -1){
        goto error;
    }
    sigchld_action.sa_flags = SA_SIGINFO | SA_RESTART;
    if(sigaction(SIGCHLD, &(sigchld_action), NULL) == -1){
        goto error;
    }
    
    // Attach to the target process
    process_to_inject_notification_event = NONE;
    if(ptrace(PTRACE_ATTACH, (pid_t)process_to_inject_pid, 0, 0) == -1){
        goto error;
    }
    target_process_attached = true;

    // Wait for stop after attaching
    while(process_to_inject_notification_event != STOP){
        while((ret = sem_wait(&process_to_inject_notify_event_semaphore)) == -1 && errno == EINTR);
        if(ret == -1){
            goto error;
        }
    }
    printf("Process has stopped. We are attached to it. \n");

    // Continue the process until syscall-enter
    process_to_inject_notification_event = NONE;
    if(ptrace(PTRACE_SYSCALL, (pid_t)process_to_inject_pid, 0, 0) == -1){
        goto error;
    }

    // Stop on syscall-enter
    while(process_to_inject_notification_event != STOP){
        while((ret = sem_wait(&process_to_inject_notify_event_semaphore)) == -1 && errno == EINTR);
        if(ret == -1){
            goto error;
        }
    }

    // Continue the process until syscall-exit
    process_to_inject_notification_event = NONE;
    if(ptrace(PTRACE_SYSCALL, (pid_t)process_to_inject_pid, 0, 0) == -1){
        goto error;
    }

    // Stop on syscall exit
    while(process_to_inject_notification_event != STOP){
        while((ret = sem_wait(&process_to_inject_notify_event_semaphore)) == -1 && errno == EINTR);
        if(ret == -1){
            goto error;
        }
    }
    printf("Process has stopped on syscall exit\n");
    
    // Hijack the process to do some fun stuff :)

    struct user_regs_struct regs;
    struct user_regs_struct saved_regs;

    if(ptrace(PTRACE_GETREGS, process_to_inject_pid, NULL, &regs) == -1){
        goto error;
    }

    // Save the registers for thread restoration after the hijack
    memcpy(&saved_regs, &regs, sizeof(struct user_regs_struct));


    void* target_executable_buffer = NULL;
    if(allocate_memory_on_target(sysconf(_SC_PAGESIZE), &regs, &target_executable_buffer) == false){
        goto error;
    }

    // Write to the target executable buffer:
    //      NOP
    //      NOP
    //      NOP
    //      JMP -1
    //      NOP
    //      NOP
    //      NOP
    if(ptrace (PTRACE_POKEDATA, process_to_inject_pid, target_executable_buffer, 0x909090FDEB909090) == -1){
        goto error;
    }

    // Allocate memory for stack
    memcpy(&regs, &saved_regs, sizeof(struct user_regs_struct)); // Reset registers values
    void* allocated_memory_for_stack = NULL;
    if(allocate_memory_on_target(sysconf(_SC_PAGESIZE), &regs, &allocated_memory_for_stack) == false){
        goto error;
    }
    void* new_thread_stack = (char*)allocated_memory_for_stack + 2048;


    // Create new thread //
    memcpy(&regs, &saved_regs, sizeof(struct user_regs_struct)); // Reset registers values

    // Set clone parameters
    regs.rdi = (long)target_executable_buffer;
    regs.rsi = (long)new_thread_stack;
    regs.rdx = 0x3d0f00 & (~( CLONE_CHILD_SETTID | CLONE_SETTLS | CLONE_PARENT_SETTID ));
    regs.rcx = 0x0;

    if(call_function_on_target(clone_in_target, &regs) == false){
        goto error;
    }

    printf("New thread id: %p\n", (void*)regs.rax);

    // Continue the thread, restoring original context
    if(ptrace(PTRACE_SETREGS, process_to_inject_pid, NULL, &saved_regs) == -1){
        goto error;
    }
    
error:
    if(target_process_maps != NULL){
        fclose(target_process_maps);
        target_process_maps = NULL;
    }
    if(target_process_attached == true){
        if(ptrace(PTRACE_DETACH, process_to_inject_pid, NULL, 0) != -1){
            target_process_attached = false;
        } // Best-effort: can't do anything if an error exists.
    }
    return 0;
}
