//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdlib.h>
#include <sys/mman.h>
#include <stdio.h>

int main(){
    void* mapped_area = mmap(0, 1024, PROT_EXEC | PROT_WRITE, MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);
    printf("mapped_area: %p\n", mapped_area);
}
