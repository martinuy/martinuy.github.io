#!/bin/bash

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

args=("$@")
rm -rf injector && gcc -o injector injector.c -ldl -pthread && ./injector $args
