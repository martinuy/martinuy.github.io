#!/bin/sh

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

rm -rf canaries && gcc -o canaries -fstack-protector-all canaries.c && ./canaries
