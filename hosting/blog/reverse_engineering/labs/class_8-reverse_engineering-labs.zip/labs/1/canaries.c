//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>

static void f();

int main () {
	f();
	return 0;
}

void f() {
	printf("f was called!\n");
}
