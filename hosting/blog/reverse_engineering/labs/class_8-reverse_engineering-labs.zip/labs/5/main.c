//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>

int main(void) {

    long a = 0x7FFFFFFFFFFFFFFF;

    printf("a (before): %ld\n", a);

    a = a + 0x1;

    printf("a (after): %ld\n", a);

    return 0;
}
