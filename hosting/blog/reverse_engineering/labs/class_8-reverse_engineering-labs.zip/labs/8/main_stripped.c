//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>
#include <stdlib.h>

#define HEADER_SIZE 15U

int main(void) {

    unsigned char user_data_size = 250U;

    unsigned char buffer_size = user_data_size + HEADER_SIZE;

    char* buffer = (char*)malloc(buffer_size);

    printf("buffer_size: %u\n", buffer_size);

    return 0;
}
