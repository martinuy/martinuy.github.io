//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>
#include <stdlib.h>

#define HEADER_SIZE 15U

int main(void) {

    // User input: 250 data bytes.
    unsigned char user_data_size = 250U;

    // Buffer size is user_datasize (250 bytes) + HEADER_SIZE (15 bytes) =
    // 265 bytes. However, unsigned char data type can store up to 255. Thus,
    // an overflow occurred and buffer_size actual value is 9.
    unsigned char buffer_size = user_data_size + HEADER_SIZE;

    char* buffer = (char*)malloc(buffer_size);

    // Now we have a buffer with size = 9 bytes and we may copy 250 bytes
    // of data causing a memory overflow.

    printf("buffer_size: %u\n", buffer_size);

    return 0;
}
