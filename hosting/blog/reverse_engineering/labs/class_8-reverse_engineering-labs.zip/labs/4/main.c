//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>

int main(void) {

    unsigned long a = 0xFFFFFFFFFFFFFFFE;

    a = a + 0x5;

    printf("a: %lu\n", a);

    return 0;
}
