//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#ifndef LIBVULN_H
#define LIBVULN_H

extern void win_function(void);
extern void vuln_function(char* buff);

#endif // LIBVULN_H
