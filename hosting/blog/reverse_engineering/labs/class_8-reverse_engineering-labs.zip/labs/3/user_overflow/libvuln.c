//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <setjmp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "libvuln.h"

static jmp_buf restoration_point;

void win_function(void) {
	printf("You win!!!\n");
	longjmp(&restoration_point[0], 1);
}

static void vuln_function_internal(char* buff) {
	char stack_buff[4];
	unsigned int len = *(unsigned int*)buff;
	memcpy(stack_buff, buff+sizeof(unsigned int), len);
}

void vuln_function(char* buff) {
	if (setjmp(&restoration_point[0]) == 0) {
		vuln_function_internal(buff);
	}
	return;
}
