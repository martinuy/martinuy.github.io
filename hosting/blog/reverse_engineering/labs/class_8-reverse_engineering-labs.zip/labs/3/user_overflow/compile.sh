#!/bin/bash

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

rm -rf libvuln.o libvuln.so client.o client && gcc -m32 -g -o libvuln.so -fstack-protector-all -fPIC -shared libvuln.c && gcc -m32 -g -Wl,-rpath . -o client client.c -L. -lvuln -ldl && ./client
