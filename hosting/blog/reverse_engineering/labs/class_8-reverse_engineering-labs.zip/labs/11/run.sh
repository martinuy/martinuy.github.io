#!/bin/bash

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

rm -rf main.o
rm -rf main

gcc -g -o main -m32 --no-stack-protector main.c

chmod +x main

./main
