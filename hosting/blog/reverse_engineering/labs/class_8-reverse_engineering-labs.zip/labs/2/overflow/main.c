//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <linux/fs.h>
#include <linux/gfp.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/ioctl.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <linux/thread_info.h>
#include <linux/uaccess.h>

#include "overflow.h"

#define SUCCESS 0
#define ERROR -1

struct __jmp_buf {
	unsigned long __rbx;
	unsigned long __rsp;
	unsigned long __rbp;
	unsigned long __r12;
	unsigned long __r13;
	unsigned long __r14;
	unsigned long __r15;
	unsigned long __rip;
};
extern int setjmp(struct __jmp_buf*);
extern void longjmp(struct __jmp_buf*, int);

void overflow_win(void);
void vuln_function(char* src);
static long unlocked_device_ioctl(struct file *f, unsigned int cmd, unsigned long arg);

static unsigned int overflow_win_enabled = 0;
static struct __jmp_buf vuln_function_call_site;
static struct __jmp_buf win_function_call_site;
static const struct file_operations fops = {
	.unlocked_ioctl = unlocked_device_ioctl,
};

void overflow_win_trampoline(void) {
	setjmp(&win_function_call_site);
	overflow_win();
}

void overflow_win(void) {
	if (overflow_win_enabled) {
		printk("You win!!!\n");
		longjmp(&vuln_function_call_site, 1);
	}
}

void vuln_function(char* src) {
	char stack_buffer[4] = {0x0};
	unsigned int len = *((unsigned int*)src);
	if (len > (MAX_SIZE_IOCTL_COPY_BUFFER - sizeof(unsigned int))) {
		len = MAX_SIZE_IOCTL_COPY_BUFFER - sizeof(unsigned int);
	}
	memcpy(stack_buffer, src+sizeof(unsigned int), len);
	return;
}

static long unlocked_device_ioctl(struct file *f, unsigned int cmd, unsigned long arg) {
	long ret_val = SUCCESS;
	char* ioctl_copy_buffer = NULL;

	printk("unlocked_device_ioctl (start)\n");
	printk("cmd: %u, arg: %lu\n", cmd, arg);

	switch(cmd) {
	case IOCTL_COPY_BUFFER:
		if (arg != 0U) {
			printk("IOCTL_COPY_BUFFER\n");
			ioctl_copy_buffer = (char*)kmalloc(MAX_SIZE_IOCTL_COPY_BUFFER, GFP_KERNEL);
			if (ioctl_copy_buffer == NULL) {
				ret_val = ERROR;
				goto cleanup;
			}
			printk("ioctl_copy_buffer: %p\n", ioctl_copy_buffer);
			*(unsigned int*)ioctl_copy_buffer = 0U;
			if (copy_from_user(ioctl_copy_buffer, (char*)arg, MAX_SIZE_IOCTL_COPY_BUFFER) != 0) {
				ret_val = ERROR;
				goto cleanup;
			}
		}
		if (setjmp(&vuln_function_call_site) == 0) {
			vuln_function(ioctl_copy_buffer);
		}
		break;
	case IOCTL_LEAK_INFO:
		printk("IOCTL_LEAK_INFO\n");
		if (copy_to_user((char*)arg, (void*)&(current->stack_canary), sizeof(void*)) != 0) {
			ret_val = ERROR;
			goto cleanup;
		}
		if (copy_to_user((char*)(arg+sizeof(unsigned long)), &(win_function_call_site.__rip), sizeof(void*)) != 0) {
			ret_val = ERROR;
			goto cleanup;
		}
		break;
	}
cleanup:
	if (ioctl_copy_buffer != NULL) {
		kfree(ioctl_copy_buffer);
	}
	printk("unlocked_device_ioctl (end)\n");
	return ret_val;
}

static void __exit overflow_cleanup_module(void) {

	printk("overflow_cleanup_module (start)\n");
	unregister_chrdev(MAJOR_NUM, DEVICE_NAME);
	printk("overflow_cleanup_module (start)\n");
}

static int __init overflow_init_module(void) {
	int call_val;

    printk("overflow_init_module (start)\n");

    overflow_win_trampoline();
    overflow_win_enabled = 1U;

    call_val = register_chrdev(MAJOR_NUM, DEVICE_NAME, &fops);
    printk("register_chrdev: %d\n", call_val);

    printk("overflow_init_module (start)\n");
	return 0;
}

module_init(overflow_init_module);
module_exit(overflow_cleanup_module);
MODULE_LICENSE("GPL");
