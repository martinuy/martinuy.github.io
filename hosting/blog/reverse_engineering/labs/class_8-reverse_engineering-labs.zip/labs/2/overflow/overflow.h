//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#ifndef OVERFLOW_H
#define OVERFLOW_H

#define DEVICE_NAME "overflow_dev"
#define MAJOR_NUM 100

// IOCTLs
#define IOCTL_COPY_BUFFER 1U
#define IOCTL_LEAK_INFO 3U

#define MAX_SIZE_IOCTL_COPY_BUFFER 32U

#endif // OVERFLOW_H
