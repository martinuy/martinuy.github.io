#!/bin/sh

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

make clean && make all && $(xz --compress --stdout overflow.ko > overflow.ko.xz) && chmod +x overflow.ko.xz && rm -rf overflow_client && gcc -o overflow_client overflow_client.c && chmod +x overflow_client
