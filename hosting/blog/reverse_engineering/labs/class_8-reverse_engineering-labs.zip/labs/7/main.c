//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>

#define HEADER_LENGTH 15
#define MAX_BUFFER_LIMIT (112 + HEADER_LENGTH)

// global_buffer (127 bytes): header (15 bytes) + data (112 bytes).
const char global_buffer[MAX_BUFFER_LIMIT] = { 0x0 };

int main(void) {

    // User input: 127 data bytes requested.
    char user_data_bytes_requested = 127;

    // Total bytes requested: user data bytes requested + 
    // fixed header (127 + 15 = 142 bytes).
    // This request must fail, as buffer has only 127 bytes.
    char total_data_requested = user_data_bytes_requested + HEADER_LENGTH;

    // Comparison against max buffer size (Is 142 > 127 ?)
    // Must enter the "if" and go to fail, as (142 > 127) is true
    // However, 142 cannot be represented with signed char. An overflow occurred and
    // value is actually -114. Given that (-114 > 127) is false, it does not enter
    // the "if" and thus does not fail.
    if (total_data_requested > MAX_BUFFER_LIMIT) {
        goto fail;
    }

    // Now we have 142 total bytes requested to get from a 127 bytes buffer.
    // That will leak information. If we combine this with sign extension
    // (-114 casted to a larger data type, extendend the sign bit), we will
    // leak much more information :-)

    // Another scenario would be to copy data to a buffer, causing a 
    // buffer overflow.

    printf("total_data_requested: %u - buffer size: %u\n", 
            (unsigned int)total_data_requested, MAX_BUFFER_LIMIT);

    return 0;
fail:
    return -1;
}
