//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>

#define HEADER_LENGTH 15
#define MAX_BUFFER_LIMIT (112 + HEADER_LENGTH)

const char global_buffer[MAX_BUFFER_LIMIT] = { 0x0 };

int main(void) {

    // User input: 127 data bytes requested.
    char user_data_bytes_requested = 127;

    char total_data_requested = user_data_bytes_requested + HEADER_LENGTH;

    if (total_data_requested > MAX_BUFFER_LIMIT) {
        goto fail;
    }

    printf("total_data_requested: %u - buffer size: %u\n", 
            (unsigned int)total_data_requested, MAX_BUFFER_LIMIT);

    return 0;
fail:
    return -1;
}
