//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>
#include <stdlib.h>

#define MAX_ALLOCATION_SIZE 0xFFU

int main(void) {

    // User input.
    unsigned int user_requested_buffer_size = -1;

    if (user_requested_buffer_size > MAX_ALLOCATION_SIZE) {
        goto fail;
    }

    char* buff = (char*)malloc(user_requested_buffer_size);

    printf("user_requested_buffer_size: %u\n", user_requested_buffer_size);
    printf("buff: %p\n", buff);

    return 0;
fail:
    return -1;
}
