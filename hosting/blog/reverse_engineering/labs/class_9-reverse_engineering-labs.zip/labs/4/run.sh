#!/bin/bash

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

rm -rf bin
mkdir bin

g++ -g -fno-stack-protector -o bin/uafvuln src/uafvuln.cpp
chmod +x bin/uafvuln

./bin/uafvuln
