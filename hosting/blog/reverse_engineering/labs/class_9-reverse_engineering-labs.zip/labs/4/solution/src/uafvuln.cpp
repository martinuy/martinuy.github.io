//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <iostream>
#include <cstdlib>
#include <cstring>

class A {
public:
	virtual void m();
};

class B {
public:
	void m();
};

void* fake_vtable[] = {
		(void*)0x0
};

void you_win(void) {
	std::cout << "You win!!!" << std::endl;
}

A* f(void){
	A a;
	const unsigned long a_ptr = (const unsigned long)&a;
	return (A*)a_ptr;
}

void f2(void) {
	char buff[16];
	*((void**)(buff+0x0)) = (void*)&(fake_vtable[0]);
}

int main() {
	fake_vtable[0] = (void*)you_win;
	A* a = f();
	f2();
	a->m();
	return 0;
}

void A::m(void) {
	std::cout << "A::m" << std::endl;
}

void B::m(void) {
	std::cout << "b::m" << std::endl;
}
