#!/bin/bash

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

rm -rf main && gcc -Wl,--rpath=/home/user/local_lab/dev/glibc/install_x86/lib -Wl,--dynamic-linker=/home/user/local_lab/dev/glibc/install_x86/lib/ld-linux.so.2 -I/home/user/local_lab/dev/glibc/install_x86/include -L/home/user/local_lab/dev/glibc/install_x86/lib -m32 -o main -g main.c && chmod +x main
