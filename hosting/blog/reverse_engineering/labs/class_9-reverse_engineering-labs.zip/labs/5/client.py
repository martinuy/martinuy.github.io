#!/usr/bin/python

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

import binascii
import socket
import struct
import random
import sys
import time

class G:
	current_id = -1
	enable_debug = True

def generate_id_or_size(i):
	return struct.pack("i",i)

def alloc_obj():
	G.current_id += 1
	return "\x01" + generate_id_or_size(G.current_id)

def free_object(i):
	return "\x02" + generate_id_or_size(i)

def call_method(i):
	return "\x03" + generate_id_or_size(i)

def allocate_array(array_data):
	return "\x04" + generate_id_or_size(len(array_data)) + array_data

def generate_input(it_count):
    if it_count == 1:
        return None
    else:
        return alloc_obj() + call_method(0) + free_object(0) + allocate_array("abcd")

def main():
    generated_input = None

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(("127.0.0.1", 9990))

    it_count = 0
    try:  
        while True:
            generated_input = generate_input(it_count)
            if generated_input is None:
                break
            if G.enable_debug:
                print "Sending: " + binascii.hexlify(generated_input)
            s.sendall(generated_input)
            it_count += 1
        s.close()
    except:
        pass

if __name__ == "__main__":
    main()    


