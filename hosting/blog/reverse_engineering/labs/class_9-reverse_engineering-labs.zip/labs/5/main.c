//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <netdb.h>
#include <netinet/in.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#define ENABLE_DEBUG 1
#define MAX_ALLOCATABLE_OBJECTS 0x00FFFFFFU

typedef enum { NONE = 0, ALLOC_OBJECT, FREE_OBJECT, CALL_METHOD, ALLOC_ARRAY } action_t;

static action_t action_state = NONE;
static unsigned int id_or_size_data_received_bytes = 0U;
static unsigned int id_or_size_data = 0U;
static unsigned int array_received_data = 0U;

static void(***allocated_objects)(void);
static void(*object_vtable)(void);

static char* currently_allocated_array = NULL;

static void process_buffer(char* buffer, unsigned int bytes_read);

static void foo(void) {
    printf("foo\n");
}

int main(void) {
    int server_socket_fd = -1;
    int server_client_socket_fd = -1;
    char read_buffer[1024];
    char* read_buffer_ptr = read_buffer;
    struct sockaddr_in server_address;
    struct sockaddr_in client_address;
    int client_address_length = sizeof(client_address);
    memset(&server_address, 0, sizeof(server_address));
    memset(&client_address, 0, sizeof(client_address));
    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = INADDR_ANY;
    server_address.sin_port = htons(9990);

    allocated_objects = (void(***)(void))malloc(sizeof(void*)*MAX_ALLOCATABLE_OBJECTS);
    if (allocated_objects == NULL) {
        exit(-1);
    }
    memset(allocated_objects, 0, sizeof(void*)*MAX_ALLOCATABLE_OBJECTS);
    object_vtable = foo;

    server_socket_fd = socket(AF_INET, SOCK_STREAM, 0);
    if(server_socket_fd == -1){
        goto error;
    }

    if (bind(server_socket_fd, (struct sockaddr*)&server_address, sizeof(server_address)) == -1) {
        goto error;
    }
   
    if(listen(server_socket_fd, 2) == -1){
        goto error;
    }

    printf("Server is listening for client connection.\n");

    server_client_socket_fd = accept(server_socket_fd, (struct sockaddr*)&client_address, &client_address_length);

    if(server_client_socket_fd == -1){
        goto error;
    }

    printf("Successfully established connection with a client.\n");

    while(true) {
        int bytes_read = 0;
        memset(&read_buffer, 0, sizeof(read_buffer));
        bytes_read = read(server_client_socket_fd, read_buffer, sizeof(read_buffer));
        #ifdef ENABLE_DEBUG
        printf("Bytes read: %d\n", bytes_read);
        #endif // ENABLE_DEBUG
        if(bytes_read <= 0){
            break;
        }
        process_buffer(read_buffer, (unsigned int)bytes_read);
    }

error:
    if(server_client_socket_fd != -1){
        close(server_client_socket_fd);
        server_client_socket_fd = -1;
    }
    if(server_socket_fd != -1){
        close(server_socket_fd);
        server_socket_fd = -1;
    }
    return 0;
}

static void process_buffer(char* buffer, unsigned int bytes_read) {
    unsigned int processed_bytes = 0U;
    char* buffer_ptr = NULL;

    while (processed_bytes != bytes_read) {
        buffer_ptr = buffer + processed_bytes;
        if (action_state == NONE) {
            unsigned char new_action = (unsigned char)*buffer_ptr;
            if (new_action == 0U || new_action > 4U) {
                exit(-1);
            }
            action_state = (action_t)new_action;
            processed_bytes++;    
        } else {
            if (id_or_size_data_received_bytes < sizeof(unsigned int)) {
                *(((char*)&id_or_size_data) + id_or_size_data_received_bytes) = *buffer_ptr;
                id_or_size_data_received_bytes++;
                processed_bytes++;
            }
            if (id_or_size_data_received_bytes == sizeof(unsigned int)) {
                if (action_state == ALLOC_OBJECT || action_state == FREE_OBJECT || action_state == CALL_METHOD) {
                    if (id_or_size_data > (MAX_ALLOCATABLE_OBJECTS - 1U)) {
                        exit(-1);
                    }
                }

                if (action_state == ALLOC_OBJECT) {
                    #ifdef ENABLE_DEBUG
                    printf("Alloc object. ID: %u\n", id_or_size_data);
                    #endif // ENABLE_DEBUG
                    if (*(allocated_objects + id_or_size_data) != NULL) {
                        exit(-1);
                    }
                    *(allocated_objects + id_or_size_data) = (void(**)(void))malloc(sizeof(void*));
                    **(allocated_objects + id_or_size_data) = object_vtable;
                } else if (action_state == FREE_OBJECT) {
                    #ifdef ENABLE_DEBUG
                    printf("Free object. ID: %u\n", id_or_size_data);
                    #endif // ENABLE_DEBUG
                    if (*(allocated_objects + id_or_size_data) == NULL) {
                        exit(-1);
                    }
                    free(*(allocated_objects + id_or_size_data));
                } else if (action_state == CALL_METHOD) {
                    #ifdef ENABLE_DEBUG
                    printf("Call method. ID: %u\n", id_or_size_data);
                    #endif // ENABLE_DEBUG
                    if (*(allocated_objects + id_or_size_data) == NULL) {
                        exit(-1);
                    }
                    (***(allocated_objects + id_or_size_data))();
                } else if (action_state == ALLOC_ARRAY) {
                    if (currently_allocated_array == NULL) {
                        #ifdef ENABLE_DEBUG
                        printf("Alloc array. Size: %u\n", id_or_size_data);
                        #endif // ENABLE_DEBUG
                        currently_allocated_array = (char*)malloc(id_or_size_data);
                        if (currently_allocated_array == NULL) {
                            exit(-1);
                        }
                    } else {
                        #ifdef ENABLE_DEBUG
                        printf("Alloc array. Receiving data: %02x\n", (((unsigned int)*buffer_ptr) & 0xFF));
                        #endif // ENABLE_DEBUG
                        *(currently_allocated_array+array_received_data) = *buffer_ptr;
                        array_received_data++;
                        processed_bytes++;
                    }
                }

                if (action_state == ALLOC_OBJECT || action_state == FREE_OBJECT || action_state == CALL_METHOD || (action_state == ALLOC_ARRAY && id_or_size_data == array_received_data)) {
                    // Action completed. Reset to process next action.
                    action_state = NONE;
                    id_or_size_data_received_bytes = 0U;
                    id_or_size_data = 0U;
                    array_received_data = 0U;
                    currently_allocated_array = NULL;
                }                
            }
        }
    }
}
