//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <iostream>

class A {
public:
	void m1();
	virtual void m2();
};

class B : public A {
public:
	void m1();
	void m2();
};

int main() {

	A* a = new A();
	A* a2 = new B();
	A a3;

	B* b = new B();
	//B* b2 = new A(); // Non sense
	B b3;

	std::cout << "====================" << std::endl;
	std::cout << "a & b" << std::endl;
	std::cout << "...................." << std::endl;
	a->m1();
	b->m1();
	std::cout << "...................." << std::endl;
	a->m2();
	b->m2();
	std::cout << "...................." << std::endl;
	std::cout << std::endl;
	std::cout << std::endl;
	std::cout << "====================" << std::endl;
	std::cout << "a2" << std::endl;
	std::cout << "...................." << std::endl;
	a2->m1();
	std::cout << "...................." << std::endl;
	a2->m2();
	std::cout << "...................." << std::endl;
	std::cout << std::endl;
	std::cout << std::endl;
	std::cout << "====================" << std::endl;
	std::cout << "a3 & b3" << std::endl;
	std::cout << "...................." << std::endl;
	a3.m1();
	b3.m1();
	std::cout << "...................." << std::endl;
	a3.m2();
	b3.m2();
	std::cout << "...................." << std::endl;

	return 0;
}

void A::m1() {
	std::cout << "A.m1" << std::endl;
}

void B::m1() {
	std::cout << "B.m1" << std::endl;
}

void A::m2() {
	std::cout << "A.m2" << std::endl;
}

void B::m2() {
	std::cout << "B.m2" << std::endl;
}
