#!/bin/bash

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

rm -rf bin
mkdir bin

g++ -g -o bin/main src/main.cpp

chmod +x bin/main
./bin/main
