//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Each object contains a pointer to each superclass method, which is a waste of memory.
// On the other hand, implementing a vTable scheme would increase complexity in virtual
// methods callers. Other schemes as a unique "m" method which decides which sub-method
// to call based on a struct identity (i.e.: 1st struct field) would be possible.
typedef struct _super_t {
	void(*m)(void); // Pure virtual method
} super_t;

typedef struct _a_t {
	super_t s;
	unsigned int aF;
} a_t;

typedef struct _b_t {
	super_t s;
	char bF;
} b_t;

static a_t* newA(void);
static b_t* newB(void);

static void mA(void);
static void mB(void);

int main(void) {

	super_t* a = (super_t*)newA();
	if (a == NULL) {
		goto cleanup;
	}
	(*(a->m))();

	super_t* b = (super_t*)newB();
	if (b == NULL) {
		goto cleanup;
	}
	(*(b->m))();

cleanup:
	if (a != NULL) {
		free(a);
	}
	if (b != NULL) {
		free(b);
	}

	return 0;
}

a_t* newA(void) {
	a_t* a = (a_t*)malloc(sizeof(a_t));
	((super_t*)a)->m = mA;
	return a;
}

b_t* newB(void) {
	b_t* b = (b_t*)malloc(sizeof(b_t));
	((super_t*)b)->m = mB;
	return b;
}

void mA(void) {
	printf("mA\n");
}

void mB(void) {
	printf("mB\n");
}
