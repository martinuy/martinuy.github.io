#!/bin/bash

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

rm -rf polymorphism.o polymorphism && gcc -o polymorphism -g polymorphism.c && ./polymorphism
