#!/bin/sh

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

make clean && make all && $(xz --compress --stdout kerneluaf.ko > kerneluaf.ko.xz) && chmod +x kerneluaf.ko.xz && rm -rf kerneluaf_client && gcc -o kerneluaf_client kerneluaf_client.c && chmod +x kerneluaf_client
