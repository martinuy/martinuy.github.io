//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <linux/fs.h>
#include <linux/gfp.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/ioctl.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <linux/thread_info.h>
#include <linux/uaccess.h>

#include "kerneluaf.h"

#define SUCCESS 0
#define ERROR -1

struct __jmp_buf {
	unsigned long __rbx;
	unsigned long __rsp;
	unsigned long __rbp;
	unsigned long __r12;
	unsigned long __r13;
	unsigned long __r14;
	unsigned long __r15;
	unsigned long __rip;
};
extern int setjmp(struct __jmp_buf*);
extern void longjmp(struct __jmp_buf*, int);

typedef struct polymorphic_t {
    void(*f)(void);
} polymorphic_t;

void win(void);
void loose(void);
void vuln_function(char* src);
static long unlocked_device_ioctl(struct file *f, unsigned int cmd, unsigned long arg);
static polymorphic_t* get_polymorphic_t(void);
static void overwrite_stack_function(char* src, unsigned int len);

static unsigned int win_enabled = 0U;
static unsigned int loose_enabled = 0U;

static struct __jmp_buf vuln_function_call_site;
static struct __jmp_buf win_function_call_site;
static struct __jmp_buf loose_function_call_site;

static const struct file_operations fops = {
	.unlocked_ioctl = unlocked_device_ioctl,
};

static void(**fake_vtable)(void);

void win_trampoline(void) {
	setjmp(&win_function_call_site);
	win();
}

void win(void) {
	if (win_enabled) {
		printk("You win!!!\n");
		longjmp(&vuln_function_call_site, 1);
	}
}

void loose_trampoline(void) {
	setjmp(&loose_function_call_site);
	loose();
}

void loose(void) {
	if (loose_enabled) {
		printk("You loose!!!\n");
	}
}

static polymorphic_t* get_polymorphic_t(void) {
    volatile char buff[18];
    unsigned long p_ul;
    polymorphic_t p;
    p.f = loose;
    p_ul = (unsigned long)&p;
    return (polymorphic_t*)p_ul;
}

static void overwrite_stack_function(char* src, unsigned int len) {
    char buff[MAX_SIZE_IOCTL_COPY_BUFFER];
    memcpy(buff, src, len);
    return;
}

void vuln_function(char* src) {
    polymorphic_t* p;    
    unsigned int len = *((unsigned int*)src);
	if (len > (MAX_SIZE_IOCTL_COPY_BUFFER - sizeof(unsigned int))) {
		len = MAX_SIZE_IOCTL_COPY_BUFFER - sizeof(unsigned int);
	}
    p = get_polymorphic_t();
    overwrite_stack_function(src+sizeof(unsigned int), len);
    p->f();
    return;
}

static long unlocked_device_ioctl(struct file *f, unsigned int cmd, unsigned long arg) {
	long ret_val = SUCCESS;
	char* ioctl_copy_buffer = NULL;

	printk("unlocked_device_ioctl (start)\n");
	printk("cmd: %u, arg: %lu\n", cmd, arg);

	switch(cmd) {
	case IOCTL_COPY_BUFFER:
		printk("IOCTL_COPY_BUFFER\n");
		ioctl_copy_buffer = (char*)kmalloc(MAX_SIZE_IOCTL_COPY_BUFFER, GFP_KERNEL);
		if (ioctl_copy_buffer == NULL) {
			ret_val = ERROR;
			goto cleanup;
		}
		printk("ioctl_copy_buffer: %p\n", ioctl_copy_buffer);
		if (copy_from_user(ioctl_copy_buffer, (char*)arg, MAX_SIZE_IOCTL_COPY_BUFFER) != 0) {
			ret_val = ERROR;
			goto cleanup;
		}
		asm ("cli\n" : : :);
		if (setjmp(&vuln_function_call_site) == 0) {
			vuln_function(ioctl_copy_buffer);
		}
		asm ("sti\n" : : :);
		break;
    case IOCTL_LEAK_INFO:
        if (copy_to_user((char*)arg, &(fake_vtable[0]), sizeof(void*)) != 0) {
			ret_val = ERROR;
			goto cleanup;
		}
        break;
	}
cleanup:
	if (ioctl_copy_buffer != NULL) {
		kfree(ioctl_copy_buffer);
	}
	printk("unlocked_device_ioctl (end)\n");
	return ret_val;
}

static void __exit kerneluaf_cleanup_module(void) {

	printk("kerneluaf_cleanup_module (start)\n");
	unregister_chrdev(MAJOR_NUM, DEVICE_NAME);
    if (fake_vtable != NULL) {
        kfree(fake_vtable);
        fake_vtable = NULL;
    }
	printk("kerneluaf_cleanup_module (start)\n");
}

static int __init kerneluaf_init_module(void) {
	int call_val;

    printk("kerneluaf_init_module (start)\n");

    win_trampoline();
    win_enabled = 1U;
    loose_trampoline();
    loose_enabled = 1U;

    fake_vtable = (void(**)(void))kmalloc(sizeof(void(*)(void)), GFP_KERNEL);
    fake_vtable[0] = (void(*)(void))win_function_call_site.__rip;

    call_val = register_chrdev(MAJOR_NUM, DEVICE_NAME, &fops);
    printk("register_chrdev: %d\n", call_val);

    printk("kerneluaf_init_module (start)\n");
	return 0;
}

module_init(kerneluaf_init_module);
module_exit(kerneluaf_cleanup_module);
MODULE_LICENSE("GPL");
