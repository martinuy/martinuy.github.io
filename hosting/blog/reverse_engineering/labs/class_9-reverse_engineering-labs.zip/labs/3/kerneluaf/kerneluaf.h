//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#ifndef KERNELUAF_H
#define KERNELUAF_H

#define DEVICE_NAME "kerneluaf_dev"
#define MAJOR_NUM 101

// IOCTLs
#define IOCTL_COPY_BUFFER 1U
#define IOCTL_LEAK_INFO 3U

#define MAX_SIZE_IOCTL_COPY_BUFFER 50U

#endif // KERNELUAF_H
