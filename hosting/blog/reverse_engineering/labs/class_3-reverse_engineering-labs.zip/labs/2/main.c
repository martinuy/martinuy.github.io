//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>

int __stdcall function_a(int p1) { return ++p1; }

int __cdecl function_b(int p1) { return ++p1; }

int __fastcall function_c(int p1) { return ++p1; } 

void main(void) {
	printf("function_a: %d\n", function_a(0));
	printf("function_b: %d\n", function_b(1));
	printf("function_c: %d\n", function_c(2));
}
