//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>
#include <stdint.h>
#include <Windows.h>

typedef enum data_state {EMPTY = 0, READY, LAST } data_state_t;
static uint64_t key;

static HANDLE data_src_mutex_handle;
static data_state_t data_state;
static volatile uint64_t data_src;
static volatile uint64_t data_dst;

inline uint64_t get_clock() {
	uint64_t c;
	uint64_t n;
	__asm {
		cpuid       // serialize processor
		rdtsc       // read time stamp counter
		mov dword ptr [c + 0], eax
		mov dword ptr [c + 4], edx
	}
	for (int i = 0; i < sizeof(uint64_t); i++) {
		((char*)&n)[i] = ((char*)&c)[sizeof(uint64_t)-i-1];
	}
	return n;
}

uint64_t crypt_decrypt(uint64_t plain_data) {
	uint64_t cipher_data = plain_data;
	char* cipher_data_ptr = (char*)&cipher_data;
	for (int i = 0; i < sizeof(uint64_t); i++) {
		cipher_data_ptr[i] = cipher_data_ptr[i] ^ ~(((char*)&key)[sizeof(uint64_t)-i-1]);
	}
	return cipher_data;
}

#ifdef DEBUG_MODE
void dump_data(uint64_t d) {
	uint64_t d_local = d;
	for (int i = 0; i < sizeof(uint64_t); i++) {
		printf("d[%d] = %02x\n", i, (unsigned char)(((char*)&d_local)[i]));
	}
}
#endif // DEBUG_MODE

DWORD __stdcall t1_func(LPVOID lpThreadParameter) {
	DWORD dwWaitResult;
	unsigned int remaining_transmissions = 10;
	#ifdef DEBUG_MODE
	unsigned int current_transmission = 0x0;
	#else // DEBUG_MODE
	printf("Protected data:\n");
	#endif // DEBUG_MODE	
	while (remaining_transmissions > 0) {
		dwWaitResult = WaitForSingleObject(data_src_mutex_handle, INFINITE);
		switch (dwWaitResult) {
			case WAIT_OBJECT_0: 
				if (data_state == EMPTY) {
					remaining_transmissions--;
					if (remaining_transmissions > 0) {
						data_state = READY;
					} else {
						data_state = LAST;
					}
					data_src = crypt_decrypt(get_clock());
					#ifdef DEBUG_MODE
					printf("t_1 - transmission %d data encrypted:\n", current_transmission++);
					dump_data(data_src);
					#else // DEBUG_MODE
					for (int i = 0; i < sizeof(uint64_t); i++) {
						printf("%02x", (unsigned char)(((char*)&data_src)[i]));
					}
					#endif // DEBUG_MODE
				}
				if (!ReleaseMutex(data_src_mutex_handle)){ 
					return -1;
				}
				break; 
			case WAIT_ABANDONED: 
				return -1; 
		}
	}
	#ifndef DEBUG_MODE
	printf("\n");
	#endif // DEBUG_MODE
	return 0;
}

DWORD __stdcall t2_func(LPVOID lpThreadParameter) {
	DWORD dwWaitResult;
	#ifdef DEBUG_MODE
	unsigned int current_transmission = 0x0;
	#endif // DEBUG_MODE
	while (TRUE) {
		dwWaitResult = WaitForSingleObject(data_src_mutex_handle, INFINITE);
		switch (dwWaitResult) {
			case WAIT_OBJECT_0: 
				if (data_state == READY ||data_state == LAST ) {
					data_dst = crypt_decrypt(data_src);
					#ifdef DEBUG_MODE
					printf("t_2 - transmission %d data decrypted:\n", current_transmission);
					dump_data(data_dst);
					current_transmission++;
					#endif // DEBUG_MODE
					if (data_state == LAST) {
						return 0;
					}
					data_state = EMPTY;
				}
				if (!ReleaseMutex(data_src_mutex_handle)){ 
					return -1;
				}
				break; 
			case WAIT_ABANDONED: 
				return -1; 
		}
	}
	return 0;
}

int run_test(void) {
	uint64_t p = 0x0;
	((char*)&p)[0] = 0x01;
	((char*)&p)[1] = 0x02;
	((char*)&p)[2] = 0x03;
	((char*)&p)[3] = 0x04;
	((char*)&p)[4] = 0x05;
	((char*)&p)[5] = 0x06;
	((char*)&p)[6] = 0x07;
	((char*)&p)[7] = 0x08;
	#ifdef DEBUG_MODE
	printf("Plain data:\n");
	dump_data(p);
	printf("Encrypted data:\n");
	dump_data(crypt_decrypt(p));
	printf("Decrypted data:\n");
	dump_data(crypt_decrypt(crypt_decrypt(p)));
	#endif // DEBUG_MODE
	if (crypt_decrypt(crypt_decrypt(p)) == p && crypt_decrypt(p) != p) {
		return 0;
	}
	return -1;
}	
	
int main(void) {

	key = get_clock();
	
	if (run_test() == -1) {
		return -1;
	}

	#ifdef DEBUG_MODE
	printf("Start of transmission\n");
	#endif // DEBUG_MODE
	
	data_src_mutex_handle = CreateMutex(NULL, FALSE, NULL);
	
	HANDLE t1_handle = CreateThread(NULL, 0, t1_func, NULL, 0, NULL);
	HANDLE t2_handle = CreateThread(NULL, 0, t2_func, NULL, 0, NULL);
	
	WaitForSingleObject(t1_handle, INFINITE);
	WaitForSingleObject(t2_handle, INFINITE);
	
	#ifdef DEBUG_MODE
	printf("End of transmission\n");
	#endif // DEBUG_MODE
	
	return 0;
}
