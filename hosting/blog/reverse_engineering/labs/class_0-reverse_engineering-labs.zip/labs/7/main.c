//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>

int main(void) {

    char *a = "abc\xEA\x9F\xB9";

    int b = 0x01020304;

    int *c = &b;

    printf("a: %s\n", a);

    return 0;
}
