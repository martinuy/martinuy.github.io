//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>

int main(void) {

    int *a = (int*)0x0;
    short *b = (short*)0x0;
    int *c = (int*)0x0;

    a = a + 1;
    b = b + 1;
    c = (int*)((char*)c + 1);

    printf("a: %p, b: %p, c: %p\n", a, b, c);
}
