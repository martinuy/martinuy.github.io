//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>

int main(void) {

    printf("32 bits\n");

    struct a {
        int a_1;
    };

    union b {
        int b_1;
        char b_2;
    };

    enum c {
        C_1 = 0,
    };

    printf("sizeof(long): %d\n", sizeof(long));
    printf("sizeof(int): %d\n", sizeof(int));
    printf("sizeof(short): %d\n", sizeof(short));
    printf("sizeof(char): %d\n", sizeof(char));
    printf("sizeof(double): %d\n", sizeof(double));
    printf("sizeof(float): %d\n", sizeof(float));
    printf("sizeof(void*): %d\n", sizeof(void*));

    printf("sizeof(struct a): %d\n", sizeof(struct a));
    printf("sizeof(union b): %d\n", sizeof(union b));
    printf("sizeof(enum c): %d\n", sizeof(enum c));

    return -1;
}
