//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>

int main(void) {

    asm("nop \t\n");
    void* d = (void*)-1;
    asm("nop \t\n");
    long e = -1L;
    asm("nop \t\n");
    int f = -1;
    asm("nop \t\n");
    short g = -1;
    asm("nop \t\n");
    char h = -1;
    asm("nop \t\n");

    return -1;
}
