//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>

int main(void) {

    asm("nop \t\n");    
    char a = -1;
    asm("nop \t\n");
    short b = (short)a;
    asm("nop \t\n");
    int c = (short)a;
    asm("nop \t\n");
    long d = (long)a;
    asm("nop \t\n");
    long e = (long)b;
    asm("nop \t\n");
    long f = (long)c;
    asm("nop \t\n");

    return 0;
}
