//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>

int main(void) {

    char a = -1;
    unsigned char b = -1;

    printf("(int)a: %d, (int)b: %d\n", (int)a, (int)b);
    printf("(unsigned int)a: %u, (unsigned int)b: %u\n", (unsigned int)a, (unsigned int)b);
}
