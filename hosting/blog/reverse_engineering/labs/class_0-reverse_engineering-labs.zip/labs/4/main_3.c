//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>

int main(void) {

    asm("nop \t\n");    
    unsigned char a = 255U;
    asm("nop \t\n");
    unsigned int b = (unsigned int)a;
    asm("nop \t\n");

    printf("b: %d\n", b);
    return 0;
}
