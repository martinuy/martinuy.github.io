//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

class Main {

    public static void main(String[] args) {

        int a = 1;
        int b = 2;

        int res = a + b;

        System.out.println("res: " + res);    

    }

}
