//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>

int main(void) {

    int a = 1;
    int* b = &a;
    a = 2;

    printf("a: %d, b: %d\n", a, *b);

    *b = 3;
    printf("a: %d, b: %d\n", a, *b);

    b = (int*)0x4;
    printf("b: %d\n", *b);

    return -1;
}
