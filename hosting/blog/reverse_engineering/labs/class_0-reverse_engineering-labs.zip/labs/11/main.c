//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>

int main(void) {

    enum a_e { A = 1, B, C } a;
    struct b {
        int a;
        int b;
    } b;
    union c {
        char d;
        int e;
    } c;

    b.a = (int)A;
    b.b = 2;
    c.d = 60;
    c.e = 61;

    printf("a_e (A): %d\n", (int)A);
    printf("b.b: %d\n", b.b);
    printf("c.d: %c, c.e: %d\n", c.d, c.e);

    return 0;
}
