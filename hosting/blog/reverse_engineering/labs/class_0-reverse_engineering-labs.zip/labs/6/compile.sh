#!/bin/bash

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

rm -rf main main_2 && gcc -g -o main main.c && gcc -g -o main_2 main_2.c && chmod +x main main_2
