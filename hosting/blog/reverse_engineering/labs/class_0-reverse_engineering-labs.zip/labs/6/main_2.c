//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>

struct a {
    int m1;
};

void f1 ( struct a arg1 );

struct a f2 ( void );

void f3 ( char arg1[] );

char[] f4 ( void );

char* f5 ( char* arg1 );

int main(void) {

    return 0;
}
