//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>

struct a {
	int m1;
};

void f (struct a*);

int main(void) {

    struct a v1;

    f ( &v1 );

    

    return 0;
}

void f ( struct a *arg1 ) {
    arg1->m1 = 0;
}
