//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>

int main(void) {

    int a[2] = {0x1, 0x2};

    printf("a[0]: %d\n", a[0]);
    printf("a[1]: %d\n", a[1]);
    printf("a[-1]: %d\n", a[-1]);
    printf("*(a+1): %d\n", *(a+1));
}
