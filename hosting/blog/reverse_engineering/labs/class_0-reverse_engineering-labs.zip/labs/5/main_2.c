//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>

int main(void) {

    asm("nop\t\n");
    int a[2] = {0x1, 0x2};
    asm("nop\t\n");
    int b[] = {0x1}; // ¿es posible?
    asm("nop\t\n");
    int *c = b; // ¿es posible?
    asm("nop\t\n");
    char *d = "abcde"; // ¿es posible?
    asm("nop\t\n");
    char e[] = "abcde"; // ¿es posible?
    asm("nop\t\n");
    char *f = d; // ¿es posible?
    asm("nop\t\n");
    char g[] = d; // ¿es posible?
    asm("nop\t\n");

    printf("d: %s\n", d);
    printf("e: %s\n", e);
    printf("f: %s\n", f);
    printf("g: %s\n", g);
    return 0;
}
