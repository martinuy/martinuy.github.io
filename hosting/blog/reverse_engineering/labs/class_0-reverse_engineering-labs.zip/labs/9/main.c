//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>

int main(void) {

    int a = 0x0;

    int b = 0xFFFFFFFF;

    a |= (1 << 2);

    b &= ~(1 << 2);

    printf("a: %x, b: %x\n", a, b);

    return 0;
}
