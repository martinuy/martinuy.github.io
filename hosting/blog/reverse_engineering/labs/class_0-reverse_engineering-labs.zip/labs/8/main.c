//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>

int main(void) {

    /*
    const int a = 1;

    const int *b = &a;

    char *c = "abc";

    a = 2; // Se puede?

    *b = 3; // Se puede?

    b = (int*)0x0; // Se puede?

    c[0] = 'b'; // Se puede?

    */
    const int *d = (const int*)0x1;

    const int *const e = (const int*)0x1;

    int *const f = d; // Se puede?

    //int *g = d; // Se puede?

    //*e = 2; // Se puede?

    //e = (const int*)2; // Se puede?

    *f = 2; // Se puede?




    return 0;
}
