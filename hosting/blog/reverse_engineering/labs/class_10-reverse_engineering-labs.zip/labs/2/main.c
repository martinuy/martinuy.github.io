//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#define USER_INPUT_SIZE 200

static int hex_to_bytes(char* bytes_string, const char* hex_string, unsigned int hex_string_size);

int main(int argc, char* argv[]) {
    int i;
    int return_code = -1;
    char* bytes_string = NULL;
    char* user_input = NULL;
    char buff[10];

    user_input = (char*)malloc(sizeof(char)*(USER_INPUT_SIZE+1));
    if (user_input == NULL) {
		printf("Incorrect user_input buffer allocation\n");
		goto cleanup;
	}
    memset(user_input, 0, (USER_INPUT_SIZE+1));

    printf("%p\n", buff);

    scanf("%200s",user_input);

    unsigned int hex_string_size = strlen(user_input);
    if (hex_string_size % 2 != 0) {
        printf("Input string size must be multiple of 2\n");
        goto cleanup;
    }

    bytes_string = (char*)malloc(sizeof(char) * (hex_string_size/2));
    if (bytes_string == NULL) {
        printf("Error allocating memory\n");
        goto cleanup;
    }

    if (hex_to_bytes(bytes_string, user_input, hex_string_size) != 0) {
        printf("Error converting to bytes string\n");
        goto cleanup;
    }

    printf("bytes_string: \n");
    for (i = 0; i < hex_string_size/2; i++) {
	    printf("0x%02x", ((unsigned int)bytes_string[i])&0xFF);
        if (i + 1 < hex_string_size/2) {
            printf(", ");
        }
    }
    printf("\n");

	memcpy(buff, bytes_string, hex_string_size/2);

    asm volatile (
            "pop %%ebp\n\t"
            "ret\n\t"
        :::);

    return_code = 0;

cleanup:

    if (user_input != NULL) {
        free(user_input);
        user_input = NULL;
    }

    if (bytes_string != NULL) {
        free(bytes_string);
        bytes_string = NULL;
    }

    if (return_code == 0) {
        printf("Finish - success\n");
    }

	return return_code;
}

static int hex_to_bytes(char* bytes_string, const char* hex_string, unsigned int hex_string_size) {
    int i = 0;
    int j = 0;
    char tmp[3] = {0x0};
    for (i = 0; i <= hex_string_size; i=i+2) {
        tmp[0] = hex_string[i];
        tmp[1] = hex_string[i+1];
        sscanf(tmp, "%x", &(bytes_string[j]));
        j++;
    }
    return 0;
}

int heaven(void) {
    while(1) { 
        sleep(100);
    }
}
