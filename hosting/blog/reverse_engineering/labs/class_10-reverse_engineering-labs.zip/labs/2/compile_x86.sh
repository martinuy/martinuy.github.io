#!/bin/bash

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

##
## Script based on https://sourceware.org/glibc/wiki/Testing/Builds
##

# glibc pieces:
BUILD=/home/user/local_lab/dev/glibc/build_x86
DYNLINKER=--dynamic-linker="${BUILD}"/elf/ld.so
LINKPATH=-rpath="${BUILD}":"${BUILD}"/math:"${BUILD}"/elf:"${BUILD}"/dlfcn:"${BUILD}"/nss:"${BUILD}"/nis:"${BUILD}"/rt:"${BUILD}"/resolv:"${BUILD}"/crypt:"${BUILD}"/mathvec:"${BUILD}"/nptl
CRT1="${BUILD}"/csu/crt1.o
CRT1_PIE="${BUILD}"/csu/Scrt1.o
CRTI="${BUILD}"/csu/crti.o
CRTN="${BUILD}"/csu/crtn.o

# gcc pieces:
CRTBEGIN_STATIC=$(gcc -m32 -print-file-name="crtbeginT.o")
CRTBEGIN_PIE=$(gcc -m32 -print-file-name="crtbeginS.o")
CRTBEGIN_NORMAL=$(gcc -m32 -print-file-name="crtbegin.o")
CRTEND=$(gcc -m32 -print-file-name="crtend.o")
CRTEND_PIE=$(gcc -m32 -print-file-name="crtendS.o")
GCCINSTALL=$(gcc -m32 -print-search-dirs | grep 'install:' | sed -e 's,^install: ,,g')/32
LD=$(gcc -m32 -print-prog-name="collect2")

# Application pieces:
PROG_NAME_STATIC=main-static
PROG_SOURCE=main.c
PROG_OBJ=main.o
MAP_STATIC=mapfile-static.txt
CFLAGS="-fno-stack-protector -no-pie -m32 -g -g3 -O0"

# Compile the application.
rm -f $PROG_NAME_STATIC
rm -f $PROG_OBJ
rm -f $MAP_STATIC

# Once for static and normal builds and once for shared (PIE).
# These compilations still use the old C library headers.
gcc $CFLAGS -c $PROG_SOURCE -o $PROG_OBJ

# Link it against a hybrid combination of:
# - Newly build glibc.
# - Split out libpthread because the .so is a linker script.
# - C development environment present on the system.
# Notes:
# - LTO is not supported.
# - Profiling is not supported (-pg).
# - Only works for gcc.
# - Only works for x86.
# - Assumes we are using only the first and default multlib.

# Static build:
$LD --build-id --no-add-needed --hash-style=gnu -m elf_i386 -static -o \
$PROG_NAME_STATIC $CRT1 $CRTI $CRTBEGIN_STATIC \
-L$GCCINSTALL \
-L/usr/lib \
-Map $MAP_STATIC \
$PROG_OBJ \
objs/gettext.o \
 objs/dcigettext.o \
 objs/dcngettext.o \
 objs/dngettext.o \
 objs/ngettext.o \
 objs/finddomain.o \
 objs/loadmsgcat.o \
 objs/localealias.o \
 objs/textdomain.o \
 objs/l10nflist.o \
 objs/explodename.o \
 objs/plural.o \
 objs/plural-exp.o \
 objs/hash-string.o \
 objs/catgets.o \
 objs/open_catalog.o \
 objs/s_isinfl.o \
 objs/s_isnanl.o \
 objs/s_finitel.o \
 objs/s_copysignl.o \
 objs/s_modfl.o \
 objs/s_scalbnl.o \
 objs/s_frexpl.o \
 objs/s_signbitl.o \
 objs/s_ldexpl.o \
 objs/s_isinf.o \
 objs/s_isnan.o \
 objs/s_finite.o \
 objs/s_copysign.o \
 objs/s_modf.o \
 objs/s_scalbn.o \
 objs/s_frexp.o \
 objs/s_signbit.o \
 objs/s_ldexp.o \
 objs/s_isinff.o \
 objs/s_isnanf.o \
 objs/s_finitef.o \
 objs/s_copysignf.o \
 objs/s_modff.o \
 objs/s_scalbnf.o \
 objs/s_frexpf.o \
 objs/s_signbitf.o \
 objs/s_ldexpf.o \
 objs/s_isinff128.o \
 objs/s_isnanf128.o \
 objs/s_finitef128.o \
 objs/s_copysignf128.o \
 objs/s_modff128.o \
 objs/s_scalbnf128.o \
 objs/s_frexpf128.o \
 objs/s_signbitf128.o \
 objs/s_ldexpf128.o \
objs/fxprintf.o \
 objs/filedoalloc.o \
 objs/iofclose.o \
 objs/iofdopen.o \
 objs/iofflush.o \
 objs/iofgetpos.o \
 objs/iofgets.o \
 objs/iofopen.o \
 objs/iofopncook.o \
 objs/iofputs.o \
 objs/iofread.o \
 objs/iofsetpos.o \
 objs/ioftell.o \
 objs/wfiledoalloc.o \
 objs/iofwrite.o \
 objs/iogetdelim.o \
 objs/iogetline.o \
 objs/iogets.o \
 objs/iopadn.o \
 objs/iopopen.o \
 objs/ioputs.o \
 objs/ioseekoff.o \
 objs/ioseekpos.o \
 objs/iosetbuffer.o \
 objs/iosetvbuf.o \
 objs/ioungetc.o \
 objs/iovsprintf.o \
 objs/iovsscanf.o \
 objs/iofgetpos64.o \
 objs/iofopen64.o \
 objs/iofsetpos64.o \
 objs/fputwc.o \
 objs/fputwc_u.o \
 objs/getwc.o \
 objs/getwc_u.o \
 objs/getwchar.o \
 objs/getwchar_u.o \
 objs/iofgetws.o \
 objs/iofgetws_u.o \
 objs/iofputws.o \
 objs/iofputws_u.o \
 objs/iogetwline.o \
 objs/iowpadn.o \
 objs/ioungetwc.o \
 objs/putwc.o \
 objs/putwc_u.o \
 objs/putwchar.o \
 objs/putwchar_u.o \
 objs/putchar.o \
 objs/putchar_u.o \
 objs/fanotify_init.o \
 objs/name_to_handle_at.o \
 objs/setns.o \
 objs/process_vm_readv.o \
 objs/process_vm_writev.o \
 objs/accept.o \
 objs/bind.o \
 objs/connect.o \
 objs/getpeername.o \
 objs/getsockname.o \
 objs/getsockopt.o \
 objs/listen.o \
 objs/recv.o \
 objs/recvfrom.o \
 objs/recvmsg.o \
 objs/send.o \
 objs/sendmsg.o \
 objs/sendto.o \
 objs/setsockopt.o \
 objs/shutdown.o \
 objs/socket.o \
 objs/socketpair.o \
objs/isfdtype.o \
 objs/opensock.o \
 objs/sockatmark.o \
 objs/accept4.o \
 objs/recvmmsg.o \
 objs/sendmmsg.o \
 objs/sa_len.o \
 objs/cmsg_nxthdr.o \
 objs/ftok.o \
 objs/msgsnd.o \
 objs/msgrcv.o \
 objs/msgget.o \
 objs/msgctl.o \
 objs/semop.o \
 objs/semget.o \
 objs/semctl.o \
 objs/semtimedop.o \
 objs/shmat.o \
 objs/shmdt.o \
 objs/shmget.o \
 objs/shmctl.o \
 objs/gmon.o \
 objs/mcount.o \
 objs/profil.o \
 objs/sprofil.o \
 objs/printf_chk.o \
 objs/fprintf_chk.o \
 objs/vprintf_chk.o \
 objs/vfprintf_chk.o \
 objs/gets_chk.o \
 objs/chk_fail.o \
 objs/readonly-area.o \
 objs/fgets_chk.o \
 objs/fgets_u_chk.o \
 objs/read_chk.o \
 objs/pread_chk.o \
 objs/pread64_chk.o \
 objs/recv_chk.o \
 objs/recvfrom_chk.o \
 objs/readlink_chk.o \
 objs/readlinkat_chk.o \
 objs/getwd_chk.o \
 objs/getcwd_chk.o \
 objs/realpath_chk.o \
 objs/fread_chk.o \
 objs/fread_u_chk.o \
 objs/wctomb_chk.o \
 objs/wcscpy_chk.o \
 objs/wmemcpy_chk.o \
 objs/wmemmove_chk.o \
 objs/wmempcpy_chk.o \
 objs/wcpcpy_chk.o \
 objs/wcsncpy_chk.o \
 objs/wcscat_chk.o \
 objs/wcsncat_chk.o \
 objs/wmemset_chk.o \
 objs/wcpncpy_chk.o \
 objs/swprintf_chk.o \
 objs/vswprintf_chk.o \
 objs/valid_field.o \
 objs/valid_list_field.o \
 objs/rewrite_field.o \
 objs/proto-lookup.o \
 objs/service-lookup.o \
 objs/hosts-lookup.o \
 objs/network-lookup.o \
 objs/grp-lookup.o \
 objs/pwd-lookup.o \
 objs/ethers-lookup.o \
 objs/spwd-lookup.o \
 objs/netgrp-lookup.o \
 objs/alias-lookup.o \
 objs/sgrp-lookup.o \
 objs/key-lookup.o \
 objs/rpc-lookup.o \
 objs/nis_hash.o \
 objs/nscd_getpw_r.o \
 objs/nscd_getgr_r.o \
 objs/nscd_gethst_r.o \
 objs/nscd_getai.o \
 objs/nscd_initgroups.o \
 objs/nscd_getserv_r.o \
 objs/nscd_netgroup.o \
 objs/nscd_helper.o \
 objs/isastream.o \
 objs/getmsg.o \
 objs/getpmsg.o \
 objs/putmsg.o \
 objs/putpmsg.o \
 objs/fattach.o \
 objs/fdetach.o \
 objs/getlogin.o \
 objs/getlogin_r.o \
 objs/setlogin.o \
 objs/getlogin_r_chk.o \
 objs/getutent.o \
 objs/getutent_r.o \
 objs/getutid.o \
 objs/getutline.o \
 objs/getutid_r.o \
 objs/getutline_r.o \
 objs/utmp_file.o \
 objs/utmpname.o \
 objs/updwtmp.o \
 objs/getpt.o \
 objs/grantpt.o \
 objs/unlockpt.o \
 objs/ptsname.o \
 objs/ptsname_r_chk.o \
 objs/setutxent.o \
 objs/getutxent.o \
 objs/endutxent.o \
 objs/getutxid.o \
 objs/getutxline.o \
 objs/pututxline.o \
 objs/utmpxname.o \
 objs/updwtmpx.o \
 objs/getutmpx.o \
 objs/getutmp.o \
 objs/longjmp.o \
 objs/__longjmp.o \
 objs/jmp-unwind.o \
 objs/signal.o \
 objs/raise.o \
 objs/killpg.o \
 objs/sigaction.o \
 objs/sigprocmask.o \
 objs/kill.o \
 objs/sigpending.o \
 objs/sigsuspend.o \
 objs/sigwait.o \
 objs/sigblock.o \
 objs/sigsetmask.o \
 objs/sigpause.o \
 objs/sigvec.o \
 objs/sigstack.o \
 objs/sigaltstack.o \
 objs/sigintr.o \
 objs/sigsetops.o \
 objs/sigempty.o \
 objs/sigfillset.o \
 objs/sigaddset.o \
 objs/sigdelset.o \
 objs/sigismem.o \
 objs/sigreturn.o \
 objs/siggetmask.o \
 objs/sysv_signal.o \
 objs/sigisempty.o \
 objs/sigandset.o \
 objs/sigorset.o \
 objs/allocrtsig.o \
 objs/sigtimedwait.o \
 objs/sigwaitinfo.o \
 objs/sigqueue.o \
 objs/sighold.o \
 objs/sigrelse.o \
 objs/sigignore.o \
 objs/sigset.o \
 objs/atof.o \
 objs/atoi.o \
 objs/atol.o \
 objs/atoll.o \
 objs/abort.o \
 objs/bsearch.o \
 objs/qsort.o \
 objs/msort.o \
 objs/getenv.o \
 objs/putenv.o \
 objs/setenv.o \
 objs/secure-getenv.o \
 objs/exit.o \
 objs/on_exit.o \
 objs/atexit.o \
 objs/cxa_atexit.o \
 objs/cxa_finalize.o \
 objs/old_atexit.o \
 objs/quick_exit.o \
 objs/at_quick_exit.o \
 objs/cxa_at_quick_exit.o \
 objs/cxa_thread_atexit_impl.o \
objs/abs.o \
 objs/labs.o \
 objs/llabs.o \
 objs/div.o \
 objs/ldiv.o \
 objs/lldiv.o \
 objs/mblen.o \
 objs/mbstowcs.o \
 objs/mbtowc.o \
 objs/wcstombs.o \
 objs/wctomb.o \
 objs/random.o \
 objs/random_r.o \
 objs/rand.o \
 objs/rand_r.o \
 objs/drand48.o \
 objs/erand48.o \
 objs/lrand48.o \
 objs/nrand48.o \
 objs/mrand48.o \
 objs/jrand48.o \
 objs/srand48.o \
 objs/seed48.o \
 objs/lcong48.o \
 objs/drand48_r.o \
 objs/erand48_r.o \
 objs/lrand48_r.o \
 objs/nrand48_r.o \
 objs/mrand48_r.o \
 objs/jrand48_r.o \
 objs/srand48_r.o \
 objs/seed48_r.o \
 objs/lcong48_r.o \
 objs/drand48-iter.o \
 objs/getrandom.o \
 objs/getentropy.o \
 objs/strfromf.o \
 objs/strfromd.o \
 objs/strfroml.o \
 objs/strtol.o \
 objs/strtoul.o \
 objs/strtoll.o \
 objs/strtoull.o \
 objs/strtol_l.o \
 objs/strtoul_l.o \
 objs/strtoll_l.o \
 objs/strtoull_l.o \
 objs/strtof.o \
 objs/strtod.o \
 objs/strtold.o \
 objs/strtof_l.o \
 objs/strtod_l.o \
 objs/strtold_l.o \
 objs/strtof_nan.o \
 objs/strtod_nan.o \
 objs/strtold_nan.o \
 objs/system.o \
 objs/canonicalize.o \
 objs/a64l.o \
 objs/l64a.o \
 objs/rpmatch.o \
 objs/errno.o \
 objs/errno-loc.o \
 objs/iconv_open.o \
 objs/iconv.o \
 objs/iconv_close.o \
 objs/gconv_open.o \
 objs/gconv.o \
 objs/gconv_close.o \
 objs/gconv_db.o \
 objs/gconv_conf.o \
 objs/gconv_builtin.o \
 objs/gconv_simple.o \
 objs/gconv_trans.o \
 objs/gconv_cache.o \
 objs/gconv_dl.o \
 objs/setlocale.o \
 objs/findlocale.o \
 objs/loadlocale.o \
 objs/loadarchive.o \
 objs/localeconv.o \
 objs/nl_langinfo.o \
 objs/nl_langinfo_l.o \
 objs/mb_cur_max.o \
 objs/newlocale.o \
 objs/duplocale.o \
 objs/freelocale.o \
 objs/uselocale.o \
 objs/lc-ctype.o \
 objs/lc-messages.o \
 objs/lc-monetary.o \
 objs/lc-numeric.o \
 objs/lc-time.o \
 objs/lc-paper.o \
 objs/lc-name.o \
 objs/lc-address.o \
 objs/lc-telephone.o \
 objs/lc-measurement.o \
 objs/lc-identification.o \
 objs/lc-collate.o \
 objs/C-ctype.o \
 objs/C-messages.o \
 objs/C-monetary.o \
 objs/C-numeric.o \
 objs/C-time.o \
 objs/C-paper.o \
 objs/C-name.o \
 objs/C-address.o \
 objs/C-telephone.o \
 objs/C-measurement.o \
 objs/C-identification.o \
 objs/C-collate.o \
 objs/SYS_libc.o \
 objs/C_name.o \
 objs/xlocale.o \
 objs/localename.o \
 objs/global-locale.o \
 objs/coll-lookup.o \
 objs/assert.o \
 objs/assert-perr.o \
 objs/__assert.o \
 objs/ctype.o \
 objs/ctype-c99.o \
 objs/ctype-extn.o \
 objs/ctype-c99_l.o \
 objs/ctype_l.o \
 objs/isctype.o \
 objs/ctype-info.o \
 objs/bindtextdom.o \
 objs/dcgettext.o \
 objs/dgettext.o \
 objs/setfpucw.o \
 objs/fpu_control.o \
 objs/setjmp.o \
 objs/sigjmp.o \
 objs/bsd-setjmp.o \
 objs/bsd-_setjmp.o \
objs/iovswscanf.o \
 objs/swscanf.o \
 objs/wgenops.o \
 objs/wstrops.o \
 objs/wfileops.o \
 objs/iofwide.o \
 objs/fwide.o \
 objs/wmemstream.o \
 objs/clearerr.o \
 objs/feof.o \
 objs/ferror.o \
 objs/fileno.o \
 objs/fputc.o \
 objs/freopen.o \
 objs/fseek.o \
 objs/getc.o \
 objs/getchar.o \
 objs/memstream.o \
 objs/pclose.o \
 objs/putc.o \
 objs/rewind.o \
 objs/setbuf.o \
 objs/setlinebuf.o \
 objs/vasprintf.o \
 objs/iovdprintf.o \
 objs/vscanf.o \
 objs/vsnprintf.o \
 objs/obprintf.o \
 objs/fcloseall.o \
 objs/fseeko.o \
 objs/ftello.o \
 objs/freopen64.o \
 objs/fseeko64.o \
 objs/ftello64.o \
 objs/__fbufsize.o \
 objs/__freading.o \
 objs/__fwriting.o \
 objs/__freadable.o \
 objs/__fwritable.o \
 objs/__flbf.o \
 objs/__fpurge.o \
 objs/__fpending.o \
 objs/__fsetlocking.o \
 objs/libc_fatal.o \
 objs/fmemopen.o \
 objs/oldfmemopen.o \
 objs/vtables.o \
 objs/clearerr_u.o \
 objs/feof_u.o \
 objs/ferror_u.o \
 objs/fputc_u.o \
 objs/getc_u.o \
 objs/getchar_u.o \
 objs/iofflush_u.o \
 objs/putc_u.o \
 objs/peekc.o \
 objs/iofread_u.o \
 objs/iofwrite_u.o \
 objs/iofgets_u.o \
 objs/iofputs_u.o \
 objs/fileops.o \
 objs/genops.o \
 objs/stdfiles.o \
 objs/stdio.o \
 objs/strops.o \
 objs/sdlopen.o \
 objs/sdlclose.o \
 objs/sdlsym.o \
 objs/sdlvsym.o \
 objs/sdlerror.o \
 objs/sdladdr.o \
 objs/sdladdr1.o \
 objs/sdlinfo.o \
 objs/sdlmopen.o \
 objs/malloc.o \
 objs/morecore.o \
 objs/mcheck.o \
 objs/mtrace.o \
 objs/obstack.o \
 objs/reallocarray.o \
 objs/scratch_buffer_grow.o \
 objs/scratch_buffer_grow_preserve.o \
 objs/scratch_buffer_set_array_size.o \
 objs/dynarray_at_failure.o \
 objs/dynarray_emplace_enlarge.o \
 objs/dynarray_finalize.o \
 objs/dynarray_resize.o \
 objs/dynarray_resize_clear.o \
 objs/alloc_buffer_alloc_array.o \
 objs/alloc_buffer_allocate.o \
 objs/alloc_buffer_copy_bytes.o \
 objs/alloc_buffer_copy_string.o \
 objs/alloc_buffer_create_failure.o \
 objs/set-freeres.o \
 objs/thread-freeres.o \
 objs/strcat.o \
 objs/strchr.o \
 objs/strcmp.o \
 objs/strcoll.o \
 objs/strcpy.o \
 objs/strcspn.o \
 objs/strverscmp.o \
 objs/strdup.o \
 objs/strndup.o \
 objs/strerror.o \
 objs/_strerror.o \
$BUILD/nptl/libpthread.a \
--start-group -lgcc -lgcc_eh $BUILD/libc.a --end-group \
$CRTEND $CRTN
