//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

class A {
public:
	virtual int m(void) = 0;
};

class B : public A {
public:
	int m(void);
};

class C : public A {
public:
	int m(void);
};

int B::m(void) {
	return 1;
}

int C::m(void) {
	return 2;
}

int main(void) {
	int res = 0;

	A* b = new B();
	A* c = new C();

	// Avoid clang optimizations and generate an indirect call
	volatile unsigned long bu = reinterpret_cast<unsigned long>(&b);
	volatile unsigned long cu = reinterpret_cast<unsigned long>(&c);

	A* bb = *(reinterpret_cast<A**>(bu));
	A* cc = *(reinterpret_cast<A**>(cu));

	res += bb->m();
	res += cc->m();

	return res;
}
