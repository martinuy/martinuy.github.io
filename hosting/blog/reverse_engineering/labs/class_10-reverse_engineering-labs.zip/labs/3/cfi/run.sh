#!/bin/bash

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

rm -rf main.o main

clang++ -g -o main -Wno-weak-vtables -std=c++11 -fvisibility=hidden -flto -fsanitize=cfi-vcall main.cpp

chmod +x main

./main

echo $?
