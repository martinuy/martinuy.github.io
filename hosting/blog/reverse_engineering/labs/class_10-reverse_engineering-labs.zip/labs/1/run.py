#!/usr/bin/python

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

import sys
import pexpect
import re
import struct

def main():
    ptarget = pexpect.spawn("./main-static", ['env'], env={})
    ptarget.expect("\n")
    ptr_buff = int(ptarget.before, 16)
    print "Buff: "+ hex(ptr_buff)

    payload = "00" # TODO: fill

    print "payload: " + payload

    ptarget.sendline(payload)

    ptarget.logfile = sys.stdout
    ptarget.expect(pexpect.EOF)

def string_to_hex_string(string):
    hex_string = ""
    for i in string:
        hex_string += hex(ord(i)).replace("0x", "")
    return hex_string

def reverse_byte_string(byte_string):
    reversed_byte_string = ""
    for i in range(0, len(byte_string)):
        if (i % 2) == 0:
            reversed_byte_string = byte_string[i] + byte_string[i+1] + reversed_byte_string
    return reversed_byte_string

if __name__ == "__main__":
    main()
