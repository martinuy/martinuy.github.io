#!/bin/bash

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

##
## Script based on https://sourceware.org/glibc/wiki/Testing/Builds
##

# glibc pieces:
BUILD=/home/user/local_lab/dev/glibc/build_x86
DYNLINKER=--dynamic-linker="${BUILD}"/elf/ld.so
LINKPATH=-rpath="${BUILD}":"${BUILD}"/math:"${BUILD}"/elf:"${BUILD}"/dlfcn:"${BUILD}"/nss:"${BUILD}"/nis:"${BUILD}"/rt:"${BUILD}"/resolv:"${BUILD}"/crypt:"${BUILD}"/mathvec:"${BUILD}"/nptl
CRT1="${BUILD}"/csu/crt1.o
CRT1_PIE="${BUILD}"/csu/Scrt1.o
CRTI="${BUILD}"/csu/crti.o
CRTN="${BUILD}"/csu/crtn.o

# gcc pieces:
CRTBEGIN_STATIC=$(gcc -m32 -print-file-name="crtbeginT.o")
CRTBEGIN_PIE=$(gcc -m32 -print-file-name="crtbeginS.o")
CRTBEGIN_NORMAL=$(gcc -m32 -print-file-name="crtbegin.o")
CRTEND=$(gcc -m32 -print-file-name="crtend.o")
CRTEND_PIE=$(gcc -m32 -print-file-name="crtendS.o")
GCCINSTALL=$(gcc -m32 -print-search-dirs | grep 'install:' | sed -e 's,^install: ,,g')/32
LD=$(gcc -m32 -print-prog-name="collect2")

# Application pieces:
PROG_NAME_STATIC=main-static
PROG_SOURCE=main.c
PROG_OBJ=main.o
MAP_STATIC=mapfile-static.txt
CFLAGS="-fno-stack-protector -no-pie -m32 -g -g3 -O0"

# Compile the application.
rm -f $PROG_NAME_STATIC
rm -f $PROG_OBJ
rm -f $MAP_STATIC

# Once for static and normal builds and once for shared (PIE).
# These compilations still use the old C library headers.
gcc $CFLAGS -c $PROG_SOURCE -o $PROG_OBJ

# Link it against a hybrid combination of:
# - Newly build glibc.
# - Split out libpthread because the .so is a linker script.
# - C development environment present on the system.
# Notes:
# - LTO is not supported.
# - Profiling is not supported (-pg).
# - Only works for gcc.
# - Only works for x86.
# - Assumes we are using only the first and default multlib.

# Static build:
$LD --build-id --no-add-needed --hash-style=gnu -m elf_i386 -static -o \
$PROG_NAME_STATIC $CRT1 $CRTI $CRTBEGIN_STATIC \
-L$GCCINSTALL \
-L/usr/lib \
-Map $MAP_STATIC \
$PROG_OBJ \
$BUILD/nptl/libpthread.a \
--start-group -lgcc -lgcc_eh $BUILD/libc.a --end-group \
$CRTEND $CRTN
