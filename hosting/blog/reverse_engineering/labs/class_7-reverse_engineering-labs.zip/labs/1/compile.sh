#!/bin/bash

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

rm -rf main.o
rm -rf main
rm -rf ins_example.so

gcc -o main -nostdlib main.c
chmod +x main

gcc -g -shared -fPIC -DLINUX -DX86_64 -I../extras/DynamoRIO-Linux-6.2.0-2/include -I../extras/DynamoRIO-Linux-6.2.0-2/ext/include -L../extras/DynamoRIO-Linux-6.2.0-2/ext/lib64/release -L../extras/DynamoRIO-Linux-6.2.0-2/lib64/release -o ins_example.so -ldrreg -ldrmgr -ldynamorio ins_example.c
