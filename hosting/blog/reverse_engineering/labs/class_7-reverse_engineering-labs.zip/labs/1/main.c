//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

void foo();

void _start() {

    foo();

    // sys_exit(0)
    asm(
        "nop\n"
        "mov $60, %rax\n"
        "mov $0, %rdi\n"
        "syscall\n"
    );
}

void foo() {
    asm(
        "nop\n"
        "mov $0, %rax\n"
    );
}
