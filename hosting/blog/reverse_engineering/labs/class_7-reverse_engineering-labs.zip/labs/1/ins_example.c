//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include "dr_api.h"
#include "drmgr.h"

static void exit_cb(void);
static void thread_init_cb(void* drcontext);
static void thread_exit_cb(void* drcontext);
static dr_emit_flags_t app2app_cb (void* drcontext, void* tag, 
                                                instrlist_t* bb, bool for_trace,
                                                bool translating, void** user_data);
static dr_emit_flags_t analysis_cb (void* drcontext, void* tag, instrlist_t* bb, bool for_trace, bool translating, void* user_data);
static dr_emit_flags_t instruction_cb(void* drcontext, void* tag,
                                             instrlist_t* bb, instr_t* instr,
                                             bool for_trace, bool translating,
                                             void* user_data);
static dr_emit_flags_t instr2instr_cb (void* drcontext, void* tag, instrlist_t* bb, bool for_trace, bool translating, void* user_data);
static void print_current_phase(void* drcontext);
static void print_instruction_list(void* drcontext, instrlist_t* bb);
static void print_instruction(void* drcontext, instrlist_t* bb, instr_t* instr);
static void runtime_cb(void);

DR_EXPORT void
dr_client_main(client_id_t id, int argc, const char* argv[]) {
    dr_set_client_name("ins_example", "http://martin.uy/reverse");
    if (!drmgr_init())
        DR_ASSERT(false);

    dr_register_exit_event(exit_cb);

    if (!drmgr_register_bb_instrumentation_ex_event(app2app_cb, analysis_cb, instruction_cb, instr2instr_cb, NULL))
        DR_ASSERT(false);

    if (!drmgr_register_thread_init_event(thread_init_cb))
        DR_ASSERT(false);

    if (!drmgr_register_thread_exit_event(thread_exit_cb))
        DR_ASSERT(false);
}

static dr_emit_flags_t
app2app_cb (void* drcontext, void* tag, instrlist_t* bb, bool for_trace, bool translating, void** user_data) {
    dr_printf("BB without TRANSFORMATION:\n");

    print_instruction_list(drcontext, bb);

    instr_t* instr,* next_instr;
    int opcode;

    for (instr = instrlist_first_app(bb); instr != NULL; instr = next_instr) {
        next_instr = instr_get_next_app(instr);
        opcode = instr_get_opcode(instr);
        if (opcode == OP_nop) {
            instrlist_remove(bb, instr);
            instr_destroy(drcontext, instr);
        }
    }

    return DR_EMIT_DEFAULT;
}

static dr_emit_flags_t analysis_cb (void* drcontext, void* tag, instrlist_t* bb, bool for_trace, bool translating, void* user_data) {
    dr_printf("BB with TRANSFORMATION:\n");

    print_instruction_list(drcontext, bb);
 
    return DR_EMIT_DEFAULT;
}

static dr_emit_flags_t
instruction_cb(void* drcontext, void* tag, instrlist_t* bb, instr_t* instr,
                      bool for_trace, bool translating, void* user_data) {
    static bool first = true;
    if (first) {
        dr_printf("INSTRUMENTING...\n");
        first = false;
    }

    dr_insert_clean_call(drcontext, bb, instr, (void *)runtime_cb, false /* save fpstate */, 0);

    return DR_EMIT_DEFAULT;  
}

static dr_emit_flags_t instr2instr_cb (void* drcontext, void* tag, instrlist_t* bb, bool for_trace, bool translating, void* user_data) {
    dr_printf("BB with INSTRUMENTATION:\n");

    print_instruction_list(drcontext, bb);

    return DR_EMIT_DEFAULT;
}

static void runtime_cb(void) {  
    dr_printf("runtime call to hook method!\n");
}

static void thread_init_cb(void* drcontext) {

}

static void thread_exit_cb(void* drcontext) {

}

static void exit_cb(void) {
    drmgr_exit();
}

static void print_current_phase(void* drcontext) {
    dr_printf("current_phase: ");
    drmgr_bb_phase_t current_phase = drmgr_current_bb_phase(drcontext);
    switch (current_phase) {
        case DRMGR_PHASE_NONE:
            dr_printf("DRMGR_PHASE_NONE");  
            break;
        case DRMGR_PHASE_APP2APP:
            dr_printf("DRMGR_PHASE_APP2APP");  
            break;
        case DRMGR_PHASE_ANALYSIS:
            dr_printf("DRMGR_PHASE_ANALYSIS");  
            break;
        case DRMGR_PHASE_INSERTION:
            dr_printf("DRMGR_PHASE_INSERTION");  
            break;
        case DRMGR_PHASE_INSTRU2INSTRU:
            dr_printf("DRMGR_PHASE_INSTRU2INSTRU");  
            break;
        default:
        break;
    }
    dr_printf("\n");
}

static void print_instruction_list(void* drcontext, instrlist_t* bb) {
    dr_printf("------------------------\n");
    instr_t* instr,* next_instr;
    for (instr = instrlist_first_app(bb); instr != NULL; instr = next_instr) {
        next_instr = instr_get_next(instr);
        print_instruction(drcontext, bb, instr);
    }
    dr_printf("========================\n");
}

static void print_instruction(void* drcontext, instrlist_t* bb, instr_t* instr) {
    char inst_buffer[150];
    size_t inst_size = instr_disassemble_to_buffer(drcontext, instr, inst_buffer, sizeof(inst_buffer));
    if (inst_size > 0 && inst_size <= sizeof(inst_buffer)) {
        dr_printf("%s (opcode 0x%02x) - BB %p\n", inst_buffer, instr_get_opcode(instr), bb);
    }
}
