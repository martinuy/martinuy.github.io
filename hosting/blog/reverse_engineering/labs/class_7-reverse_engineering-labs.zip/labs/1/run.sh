#!/bin/bash

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

../extras/DynamoRIO-Linux-6.2.0-2/bin64/drrun -c ./ins_example.so -- main
