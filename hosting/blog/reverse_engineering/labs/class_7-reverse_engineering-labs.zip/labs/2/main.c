//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>

int check(int i) {
  const unsigned char* c = (unsigned char*)&i;
  if (((c[0] ^ c[1]) == 0x3C) && ((c[0] * c[3]) == 0x40) && c[1] != 0) {
    return 1;
  }
  return 0;
}

int main (void) {
    int res = check(4899);
    printf("res = %d\n", res);
    return 0;
}
