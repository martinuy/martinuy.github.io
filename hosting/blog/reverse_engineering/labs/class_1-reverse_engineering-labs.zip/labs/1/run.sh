#!/bin/bash

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

./main
