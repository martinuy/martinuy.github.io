#!/bin/bash

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

rm -rf main

gcc -Wl,--rpath=/home/user/local_lab/dev/glibc/install_x86_64/lib -Wl,--dynamic-linker=/home/user/local_lab/dev/glibc/install_x86_64/lib/ld-linux-x86-64.so.2 -I/home/user/local_lab/dev/glibc/install_x86_64/include -L/home/user/local_lab/dev/glibc/install_x86_64/lib -o main -g main.c

chmod +x main
