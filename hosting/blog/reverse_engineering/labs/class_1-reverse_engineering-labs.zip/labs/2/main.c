//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <stdio.h>

extern int var_a;

int var_a = 2;

static int var_b = 1;

extern int func_a(void);

static void func_b(void);

int main(void) {
    return func_a();
}

static void func_b(void) {
}
