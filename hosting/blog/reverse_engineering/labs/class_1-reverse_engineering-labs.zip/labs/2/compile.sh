#!/bin/bash

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

rm -rf func_a.o main.o main

gcc -o func_a.o -c func_a.c
gcc -o main.o  -c main.c
gcc -o main func_a.o main.o
