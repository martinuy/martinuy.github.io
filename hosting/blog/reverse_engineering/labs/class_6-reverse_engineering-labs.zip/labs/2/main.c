//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <netdb.h>
#include <netinet/in.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#define MAX_INPUT_VALUE_LENGTH 20U

static void process_buffer(char* buffer);

int main(){   
    int server_socket_fd = -1;
    int server_client_socket_fd = -1;
    char read_buffer[1024];
    char* read_buffer_ptr = read_buffer;
    struct sockaddr_in server_address;
    struct sockaddr_in client_address;
    int client_address_length = sizeof(client_address);
    memset(&server_address, 0, sizeof(server_address));
    memset(&client_address, 0, sizeof(client_address));
    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = INADDR_ANY;
    server_address.sin_port = htons(9990);

    server_socket_fd = socket(AF_INET, SOCK_STREAM, 0);
    if(server_socket_fd == -1){
        goto error;
    }

    if (bind(server_socket_fd, (struct sockaddr*)&server_address, sizeof(server_address)) == -1) {
        goto error;
    }
   
    if(listen(server_socket_fd, 2) == -1){
        goto error;
    }

    printf("Server is listening for client connection.\n");

    server_client_socket_fd = accept(server_socket_fd, (struct sockaddr*)&client_address, &client_address_length);

    if(server_client_socket_fd == -1){
        goto error;
    }

    printf("Successfully established connection with a client.\n");

    while(true) {
        int bytes_read = 0;
        memset(&read_buffer, 0, sizeof(read_buffer));
        bytes_read = read(server_client_socket_fd, read_buffer, sizeof(read_buffer));
        printf("Bytes read: %d\n", bytes_read);
        if(bytes_read <= 0){
            break;
        }
        read_buffer[sizeof(read_buffer) - 1] = 0; // Enforce null termination for read_buffer
        process_buffer(read_buffer);
    }

error:
    if(server_client_socket_fd != -1){
        close(server_client_socket_fd);
        server_client_socket_fd = -1;
    }
    if(server_socket_fd != -1){
        close(server_socket_fd);
        server_socket_fd = -1;
    }
    return 0;
}

static void process_buffer(char* buffer) {

    char* input_array = NULL;
    char* input_array_ptr = NULL;
    unsigned int buffer_length = strlen(buffer);
    unsigned char delimiter_count = 0U;
    unsigned int current_value_length = 0U;
    unsigned int chars_copied_to_buffer = 0U;

    // Count delimiters
    for (int i = 0; i < buffer_length; i++) {
        if (buffer[i] == ':') {
            delimiter_count++;
        }
    }

    if (delimiter_count == 0U) {
        return;
    }

    input_array = (char*)malloc(MAX_INPUT_VALUE_LENGTH*(delimiter_count+1) + 1);
    memset(input_array, 0, MAX_INPUT_VALUE_LENGTH*(delimiter_count+1) + 1);
    input_array_ptr = input_array;

    for (int i = 0; i < buffer_length; i++) {
        if (buffer[i] == ':') {
            current_value_length = 0U;
            continue;
        }

        if (current_value_length < MAX_INPUT_VALUE_LENGTH) {
            current_value_length++;
            *input_array_ptr = buffer[i];
            input_array_ptr++;
            chars_copied_to_buffer++;
        }
    }

    #ifdef _DEBUG
    printf("Delimiters: %u\n", delimiter_count);
    printf("Allocated buffer size: %u\n", (MAX_INPUT_VALUE_LENGTH*(delimiter_count+1)+1));
    printf("Chars copied to buffer: %u\n", chars_copied_to_buffer);
    printf("Processed buffer: %s\n", input_array);
    #endif // _DEBUG

    free(input_array);
}
