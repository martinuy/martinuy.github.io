#!/usr/bin/python

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

import socket
import struct
import random
import sys
import time

def generate_input(valid_input):
    if valid_input:
        return "aaaaaaaaaaaaa:aaaaaaaaaaaa"
    else:
        return ":"*255 + "01234567890123456789:01234567890123456789:012345678901234567890123456789"

def main():
    generated_input = ""

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(("127.0.0.1", 9990))

    request_valid_input = True
    try:  
        while True:
            generated_input = generate_input(request_valid_input)
            print "Generated input: " + str(generated_input)
            s.sendall(generated_input)
            if request_valid_input:
                request_valid_input = False
            else:
                request_valid_input = True
            time.sleep(1)
        s.close()
    except:
        pass

if __name__ == "__main__":
    main()    


