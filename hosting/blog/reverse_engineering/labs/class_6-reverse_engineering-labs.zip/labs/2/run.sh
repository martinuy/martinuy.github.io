#!/bin/bash

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

# Debug
#rm -rf main && gcc -o main -D_DEBUG main.c && ./main

# No debug
rm -rf main && gcc -o main main.c && ./main
