//
// Reverse Engineering course
// Author: martin.uy/reverse
// License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
//

#include <netdb.h>
#include <netinet/in.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

const char stage_1[] = "STAGE1";
const char stage_2[] = "STAGE2";
const char stage_3[] = "STAGE3";

int main(){   
    char overflowable_buffer[5]; 
    int server_socket_fd = -1;
    int server_client_socket_fd = -1;
    char read_buffer[80];
    char* read_buffer_ptr = read_buffer;
    const int stages_length = strlen(stage_1) + strlen(stage_2) + strlen(stage_3);
    struct sockaddr_in server_address;
    struct sockaddr_in client_address;
    int client_address_length = sizeof(client_address);
    memset(&server_address, 0, sizeof(server_address));
    memset(&client_address, 0, sizeof(client_address));
    memset(&read_buffer, 0, sizeof(read_buffer));
    memset(&overflowable_buffer, 0, sizeof(overflowable_buffer));

    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = INADDR_ANY;
    server_address.sin_port = htons(9990);

    server_socket_fd = socket(AF_INET, SOCK_STREAM, 0);
    if(server_socket_fd == -1){
        goto error;
    }

    if (bind(server_socket_fd, (struct sockaddr*)&server_address, sizeof(server_address)) == -1) {
        goto error;
    }
   
    if(listen(server_socket_fd, 2) == -1){
        goto error;
    }

    printf("Server is listening for client connection.\n");

    server_client_socket_fd = accept(server_socket_fd, (struct sockaddr*)&client_address, &client_address_length);

    if(server_client_socket_fd == -1){
        goto error;
    }

    printf("Successfully established connection with a client.\n");

    while(true) {
        int bytes_read = 0;
        bytes_read = read(server_client_socket_fd, read_buffer, sizeof(read_buffer));
        if(bytes_read == 0){
            break;
        }
        read_buffer[sizeof(read_buffer) - 1] = 0;
        read_buffer_ptr = read_buffer;
        if(bytes_read >= stages_length){
            if(memcmp(read_buffer_ptr, stage_1, strlen(stage_1)) == 0){
                read_buffer_ptr += strlen(stage_1);
                if(memcmp(read_buffer_ptr, stage_2, strlen(stage_2)) == 0){
                    read_buffer_ptr += strlen(stage_2);
                    if(memcmp(read_buffer_ptr, stage_3, strlen(stage_3)) == 0){
                        read_buffer_ptr += strlen(stage_3);
                        printf("Copying %d bytes to overflowable buffer\n", strlen(read_buffer_ptr));
                        memcpy(overflowable_buffer, read_buffer_ptr, (bytes_read - stages_length));
                        break;
                    }
                }               
            }
        }

        printf("Bytes read: %d\n", bytes_read);
    }

error:
    if(server_client_socket_fd != -1){
        close(server_client_socket_fd);
        server_client_socket_fd = -1;
    }
    if(server_socket_fd != -1){
        close(server_socket_fd);
        server_socket_fd = -1;
    }
    return 0;
}
