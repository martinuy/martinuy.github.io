#!/usr/bin/python

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

import socket
import struct
import random
import sys
import time

def generate_dumb_input():
    input_buffer = ""
    input_length = random.randint(1, 100)
    for i in range(0, input_length):
        input_buffer += struct.pack(">I", random.randint(0, 255))

    return input_buffer

def generate_smart_input():
    return ("STAGE1STAGE2STAGE3" + generate_dumb_input())[0:random.randint(1, 100)]
    

def main():
    generated_input = ""
    

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(("127.0.0.1", 9990))

    try:
        while True:    
            if len(sys.argv) > 1 and sys.argv[1] == "smart":
                generated_input  = generate_smart_input()
            else:
                generated_input = generate_dumb_input()
            print "Generated input: " + str(generated_input)
            s.sendall(generated_input)
            time.sleep(1)
        
        s.close()
    except:
        pass

if __name__ == "__main__":
    main()    


