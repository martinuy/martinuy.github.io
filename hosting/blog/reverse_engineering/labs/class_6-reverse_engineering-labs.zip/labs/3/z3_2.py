#!/usr/bin/python

#
# Reverse Engineering course
# Author: martin.uy/reverse
# License: Creative Commons Attribution-ShareAlike (CC-BY-SA)
#

from z3 import *

x = Int('x')
y = Int('y')
t = Int('t')
s = Solver()

s.add(t < x)
s.add(If(x > y, t == x, t == y))

print s.check()
print s.model()
