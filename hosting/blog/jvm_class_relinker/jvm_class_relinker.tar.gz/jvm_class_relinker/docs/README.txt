JVM Class Relinker
=============================

JVM Class Relinker is a security testing tool to invalidate classfiles
linkage checks between compilation and load times. In other words, to
enable linking against a class during compilation but loading a different
'version' of the same class at run time. Under these circumstances, all
javac previous checks become obsolete and JVM checks at load time turn
essential.

If you find any security issue in OpenJDK, please report it according to
the procedure in https://openjdk.java.net/groups/vulnerability/report

See further information in https://martin.uy/blog/jvm-class-relinker


Requirements to build and run
=============================

 * A JDK that includes 'javac' is needed to build. A JRE-only environment
   is not enough as no built artifacts are provided in this bundle.

 * Tested on JDKs 11 and 17 (Linux).


How to build and run
=============================

 * Define the JAVA_HOME environmental variable
  * I.e.: export JAVA_HOME=<path-to-your-JDK>
   * '/lib/jvm/java' will be used by default, if undefined.

 * Run ./run.sh to try the example

 * Write your own clases inner to Main and test sequences
   in Main::execute.


Changelog
=============================

.............................

Version: 1.0 - 2021-07-16

 * Initial release

.............................


License and credits
=============================

JVM Class Relinker is under GPL v3 license. See docs/gpl.txt for
further information.

Original author: Martin Balao (martin.uy)
Contributors: -

