#!/bin/bash

#
#   Martin Balao (martin.uy) - Copyright 2021
#
#   This program is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

########################
##       Configs      ##
########################

if [[ -z "${JAVA_HOME}" ]]; then
    export JAVA_HOME="/lib/jvm/java"
fi

MAIN_CLASS="Main"

######################
##      Script      ##
######################

##
# Clean
##

rm -rf bin
mkdir bin

##
# Build
##

add_exports="--add-exports java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED"

compile_command="$JAVA_HOME/bin/javac ${add_exports} -d bin src/${MAIN_CLASS}.java"

echo "================"
echo "COMPILE COMMAND:"
echo "----------------"
echo ${compile_command}
echo "================"
eval ${compile_command}

##
# Run
##

run_command="$JAVA_HOME/bin/java ${add_exports} -cp \"bin\" ${MAIN_CLASS}"

echo "RUN COMMAND:"
echo "----------------"
echo ${run_command}
echo "================"
eval ${run_command}

