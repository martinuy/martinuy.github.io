/*
 *   Martin Balao (martin.uy) - Copyright 2021
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jdk.internal.org.objectweb.asm.AnnotationVisitor;
import jdk.internal.org.objectweb.asm.ClassReader;
import jdk.internal.org.objectweb.asm.ClassVisitor;
import jdk.internal.org.objectweb.asm.ClassWriter;
import jdk.internal.org.objectweb.asm.FieldVisitor;
import jdk.internal.org.objectweb.asm.Label;
import jdk.internal.org.objectweb.asm.MethodVisitor;
import jdk.internal.org.objectweb.asm.Opcodes;
import jdk.internal.org.objectweb.asm.Type;
import jdk.internal.org.objectweb.asm.TypePath;

public final class Main {

    public interface I {
        void m();
    }

    public static final class A implements I {
        public void m() { System.out.println("A::m"); }
    }

    public static class AComp implements I {
        public void m() { System.out.println("AComp::m"); }
    }

    @JVMClassRelinker.NewLinkage(replaceClass = "AComp->A")
    public static class B extends AComp {
    }

    public static void execute() {
        I i = new B();
        i.m();
    }

    public static void main(String[] args) throws Throwable {
        System.out.println("===== Without replacement =====");
        execute();

        System.out.println("======= With replacement ======");
        JVMClassRelinker.execute();
    }

    private static final class JVMClassRelinker extends ClassLoader {
        private static JVMClassRelinker instance = null;
        private static final Class<?> enclosingClass =
                JVMClassRelinker.class.getEnclosingClass();
        private static final String enclosingClassPrefix =
                enclosingClass.getName() + "$";
        private static Map<String, byte[]> innerClsPool = new HashMap<>();
        private static Map<String, Class<?>> innerClsCache = new HashMap<>();
        private static Class<?> enclosingStripped = null;
        private static String enclosingExecuteMethodName = "execute";
        private static MethodHandle enclosingExecute = null;

        @Retention(RetentionPolicy.RUNTIME)
        public static @interface NewLinkage {
            String replaceClass() default "";
        }

        JVMClassRelinker() throws Exception {
            super(enclosingClass.getClassLoader().getParent());
        }

        static void execute() throws Throwable {
            instance = new JVMClassRelinker();
            loadInners();
            loadEnclosing();
            enclosingExecute.invoke();
        }

        protected Class<?> findClass(String name) throws ClassNotFoundException {
            if (innerClsCache.containsKey(name)) {
                return innerClsCache.get(name);
            } else if (innerClsPool.containsKey(name)) {
                byte[] innerClsBytes = innerClsPool.get(name);
                Class<?> cls = super.defineClass(name, innerClsBytes, 0,
                        innerClsBytes.length);
                innerClsCache.put(cls.getName(), cls);
                return cls;
            }
            throw new ClassNotFoundException(name);
        }

        private static void loadInners() throws Exception {
            for (Class<?> innerCls : enclosingClass.getDeclaredClasses()) {
                if (enclosingClass.equals(instance.getClass())) {
                    continue;
                }
                byte[] innerClsBytes = innerCls
                        .getResourceAsStream(innerCls.getName()+".class")
                        .readAllBytes();
                if (innerCls.isAnnotationPresent(NewLinkage.class)) {
                    NewLinkage annotation = (NewLinkage) innerCls
                            .getAnnotation(NewLinkage.class);
                    Map<String, String> classReplacements =
                            new HashMap<String, String>();
                    String[] annotationClassReplacements =
                            annotation.replaceClass()
                            .split(",");
                    for (String annotationClassReplacement :
                            annotationClassReplacements) {
                        String[] fromTo = annotationClassReplacement.split("->");
                        classReplacements.put(enclosingClassPrefix+fromTo[0],
                                enclosingClassPrefix+fromTo[1]);
                    }
                    innerClsBytes = applyClassReplacements(innerClsBytes,
                            classReplacements);
                }
                innerClsPool.put(innerCls.getName(), innerClsBytes);
            }
        }

        private static void loadEnclosing() throws Exception {
            byte[] encClsBytes = enclosingClass
                    .getResourceAsStream(enclosingClass.getName()+".class")
                    .readAllBytes();
            byte[] encStrClsBytes = stripEnclosing(encClsBytes);
            enclosingStripped = instance.defineClass(enclosingClass.getName(),
                    encStrClsBytes, 0, encStrClsBytes.length);
            enclosingExecute = MethodHandles.lookup().findStatic(
                    enclosingStripped, enclosingExecuteMethodName,
                    MethodType.methodType(void.class));
        }

        private static byte[] applyClassReplacements(byte[] cls,
                Map<String, String> classReplacements) {
            ClassReader cr = new ClassReader(cls);
            ClassWriter cw = new ClassWriter(Util.getASMOpcode() |
                    ClassWriter.COMPUTE_FRAMES);
            cr.accept(new ClassReplacer(cw, classReplacements), 0);
            return cw.toByteArray();
        }

        private static Pattern methodDescPattern = Pattern.compile("\\(.*\\).*",
                Pattern.DOTALL);

        private static String replaceDesc(String desc,
                Map<String, String> classReplacements) {
            Matcher methodDescMatcher = methodDescPattern.matcher(desc);
            if (!methodDescMatcher.matches()) {
                desc = replaceDescOne(Type.getType(desc),
                        classReplacements).getDescriptor();
            } else {
                Type asMethodType = Type.getMethodType(desc);
                Type returnType = replaceDescOne(asMethodType.getReturnType(),
                        classReplacements);
                Type[] argumentTypes = asMethodType.getArgumentTypes();
                for (int i = 0; i < argumentTypes.length; i++) {
                    argumentTypes[i] = replaceDescOne(argumentTypes[i],
                            classReplacements);
                }
                desc = Type.getMethodType(returnType, argumentTypes)
                        .getDescriptor();
            }
            return desc;
        }

        private static Type replaceDescOne(Type descType,
                Map<String, String> classReplacements) {
            if (descType.getSort() != Type.OBJECT) {
                return descType;
            }
            String rep;
            if ((rep = classReplacements.get(
                    descType.getClassName())) != null) {
                descType = Type.getObjectType(rep);
            }
            return descType;
        }

        private static String replaceClass(String klass,
                Map<String, String> classReplacements) {
            String rep = null;
            if ((rep = classReplacements.get(klass)) != null) {
                klass = rep;
            }
            return klass;
        }

        private static byte[] stripEnclosing(byte[] cls) {
            ClassReader cr = new ClassReader(cls);
            ClassWriter cw = new ClassWriter(Util.getASMOpcode() |
                    ClassWriter.COMPUTE_FRAMES);
            cr.accept(new ClassStripper(cw), 0);
            return cw.toByteArray();
        }

        private static final class ClassReplacer extends ClassVisitor {
            private Map<String, String> classReplacements;

            public ClassReplacer(ClassWriter cw,
                    Map<String, String> classReplacements) {
                super(Util.getASMOpcode(), cw);
                this.classReplacements = classReplacements;
            }

            @Override
            public void visit​(int version, int access, String name,
                    String signature, String superName, String[] interfaces) {
                superName = replaceClass(superName, classReplacements);
                super.visit(version, access, name, signature,
                        superName, interfaces);
            }

            @Override
            public MethodVisitor visitMethod(int access, String name, String desc,
                    String signature, String[] exceptions) {
                desc = replaceDesc(desc, classReplacements);
                MethodVisitor mv = super.visitMethod(access, name, desc, signature,
                        exceptions);
                return new MethodReplacer(mv, classReplacements);
            }

            @Override
            public FieldVisitor visitField(int access, String name, String desc,
                    String signature, Object value) {
                desc = replaceDesc(desc, classReplacements);
                return super.visitField(access, name, desc, signature, value);
            }
        }

        private static final class MethodReplacer extends MethodVisitor {
            private Map<String, String> classReplacements;

            protected MethodReplacer(MethodVisitor mv,
                    Map<String, String> classReplacements) {
                super(Util.getASMOpcode(), mv);
                this.classReplacements = classReplacements;
            }

            @Override
            public void visitTypeInsn(int opcode, String type) {
                type = replaceClass(type, classReplacements);
                super.visitTypeInsn(opcode, type);
            }

            @Override
            public void visitMethodInsn(int opcode, String owner, String name,
                    String desc, boolean itf) {
                owner = replaceClass(owner, classReplacements);
                desc = replaceDesc(desc, classReplacements);
                super.visitMethodInsn(opcode, owner, name, desc, itf);
            }

            @Override
            public void visitFieldInsn(int opcode, String owner, String name,
                    String desc) {
                owner = replaceClass(owner, classReplacements);
                desc = replaceDesc(desc, classReplacements);
                super.visitFieldInsn(opcode, owner, name, desc);
            }

            @Override
            public void visitMultiANewArrayInsn(String desc, int dims) {
                desc = replaceDesc(desc, classReplacements);
                super.visitMultiANewArrayInsn(desc, dims);
            }

            @Override
            public void visitLocalVariable(String name, String desc,
                    String signature, Label start, Label end, int index) {
                desc = replaceDesc(desc, classReplacements);
                super.visitLocalVariable(name, desc, signature, start, end, index);
            }
        }

        private static final class ClassStripper extends ClassVisitor {

            public ClassStripper(ClassWriter cw) {
                super(Util.getASMOpcode(), cw);
            }

            @Override
            public MethodVisitor visitMethod(int access, String name, String desc,
                    String signature, String[] exceptions) {
                if (name.equals(enclosingExecuteMethodName)) {
                    return super.visitMethod(access, name, desc, signature,
                            exceptions);
                }
                return null;
            }

            @Override
            public FieldVisitor visitField(int access, String name, String desc,
                    String signature, Object value) {
                return null;
            }

            @Override
            public void visitInnerClass(
                    final String name, final String outerName, final String innerName,
                    final int access) {
            }

            public AnnotationVisitor visitTypeAnnotation(
                    final int typeRef, final TypePath typePath, final String descriptor,
                    final boolean visible) {
                return null;
            }
        }

        private static final class Util {
            public static int getASMOpcode() {
                final double javaSpecVersion = Double.parseDouble(
                        System.getProperty("java.specification.version"));
                if (javaSpecVersion <= 11) {
                    return getASMOpcodeReflect("ASM5");
                } else {
                    return getASMOpcodeReflect("ASM7");
                }
            }

            private static int getASMOpcodeReflect(String fieldName) {
                try {
                    MethodHandle fHandle = MethodHandles.lookup()
                            .findStaticGetter(Opcodes.class, fieldName, int.class);
                    return (int)fHandle.invoke();
                } catch (Throwable t) {
                    return -1;
                }
            }
        }
    }
}
