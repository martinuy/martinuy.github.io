#ifndef	INSTRUMENTATION_H
#define	INSTRUMENTATION_H

#include <pthread.h>
#include <stdbool.h>
#include <stdint.h>

#define __PRINTF_SYNC(args...) printf(args); fsync(0)

typedef enum global_state_enum { WAITING_0, WAITING_1, WAITING_2, WAITING_3, \
        WAITING_4, OVERFLOW_READY, EXIT } global_state_t;

extern global_state_t global_state;

extern pthread_t consumer_1_tid;
extern pthread_t producer_1_tid;
extern pthread_t producer_2_tid;
extern pthread_t producer_3_tid;
extern pthread_t producer_4_tid;
extern pthread_t producer_5_tid;

extern pthread_mutex_t consumer_1_wait_mutex;
extern pthread_mutex_t producer_1_wait_mutex;
extern pthread_mutex_t producer_2_wait_mutex;
extern pthread_mutex_t producer_3_wait_mutex;
extern pthread_mutex_t producer_4_wait_mutex;
extern pthread_mutex_t producer_5_wait_mutex;

#define PRODUCER_PRE_ENQUEUE_WAIT_BLOCK(NUM) \
do { \
    if (pthread_self() == producer_##NUM##_tid) { \
        pthread_mutex_lock(&producer_##NUM##_wait_mutex); \
    } \
} while(0)

#define PRODUCER_PRE_ATTACK_WAIT_BLOCK(NUM) \
do { \
    if (pthread_self() == producer_##NUM##_tid) { \
        __PRINTF_SYNC("Producer %d: About to execute CAS. Values read: prod_head = %d, " \
                "prod_next = %d, cons_tail = %d\n", NUM, prod_head, prod_next, cons_tail); \
        __PRINTF_SYNC("Producer %d: Waiting for the attack signal\n", NUM); \
        global_state = WAITING_##NUM; \
        pthread_mutex_unlock(&producer_5_wait_mutex); \
        pthread_mutex_lock(&producer_##NUM##_wait_mutex); \
    } \
} while(0)

#define PRODUCER_POST_ATTACK_WAIT_BLOCK(NUM) \
do { \
    if (pthread_self() == producer_##NUM##_tid) { \
        __PRINTF_SYNC("Producer %d: CAS succeeded. br->br_prod_head = %d\n", NUM, \
                br->br_prod_head); \
        __PRINTF_SYNC("Producer %d: Wrote br->br_ring[%d] = %c\n", NUM, prod_head, \
                *(char*)br->br_ring[prod_head]); \
        pthread_mutex_unlock(&producer_5_wait_mutex); \
        pthread_mutex_lock(&producer_##NUM##_wait_mutex); \
    } \
} while(0)

#define LAUNCH_ATTACK \
do { \
    pthread_mutex_unlock(&producer_2_wait_mutex); \
    pthread_mutex_lock(&producer_5_wait_mutex); \
    pthread_mutex_unlock(&producer_3_wait_mutex); \
    pthread_mutex_lock(&producer_5_wait_mutex); \
    pthread_mutex_unlock(&producer_4_wait_mutex); \
    pthread_mutex_lock(&producer_5_wait_mutex); \
    pthread_mutex_unlock(&producer_1_wait_mutex); \
    pthread_mutex_lock(&producer_5_wait_mutex); \
} while(0)

#define UNLOCK_ALL_PRODUCERS \
do { \
    pthread_mutex_unlock(&producer_1_wait_mutex); \
    pthread_mutex_unlock(&producer_2_wait_mutex); \
    pthread_mutex_unlock(&producer_3_wait_mutex); \
    pthread_mutex_unlock(&producer_4_wait_mutex); \
} while(0)

#endif // INSTRUMENTATION_H
