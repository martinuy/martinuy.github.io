#ifndef	CPU_H
#define	CPU_H

#include <instrumentation.h>

#define CACHE_LINE_SIZE 64

#define	ENOBUFS		105

#define __aligned(a)

#define KASSERT(a, b)

struct mtx {
};

struct malloc_type {
};

void rmb(void) {
    asm volatile("mfence" ::: "memory");
}

void critical_enter(void) {
}

void critical_exit(void) {
}

void cpu_spinwait(void) {
    asm volatile("rep; nop" ::: "memory");
}

int atomic_cmpset_acq_int(volatile uint32_t *a, uint32_t b, uint32_t c) {
    return __atomic_compare_exchange_n(
            a,
            &b,
            c,
            false,
            __ATOMIC_RELAXED,
            __ATOMIC_RELAXED
            );
}

void atomic_store_rel_int(volatile uint32_t *a, uint32_t b) {
    __atomic_store_n(a, b, __ATOMIC_RELEASE);
}

uint32_t atomic_load_acq_32(volatile uint32_t* ptr) {
    return __atomic_load_n(ptr, __ATOMIC_ACQUIRE);
}

#endif // CPU_H
