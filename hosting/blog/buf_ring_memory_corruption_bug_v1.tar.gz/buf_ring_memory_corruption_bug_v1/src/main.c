#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "buf_ring.h"

global_state_t global_state;

pthread_t consumer_1_tid;
pthread_t producer_1_tid;
pthread_t producer_2_tid;
pthread_t producer_3_tid;
pthread_t producer_4_tid;
pthread_t producer_5_tid;

pthread_mutex_t consumer_1_wait_mutex;
pthread_mutex_t producer_1_wait_mutex;
pthread_mutex_t producer_2_wait_mutex;
pthread_mutex_t producer_3_wait_mutex;
pthread_mutex_t producer_4_wait_mutex;
pthread_mutex_t producer_5_wait_mutex;

static struct buf_ring* buf_ring = NULL;
static char* chr_ptr = NULL;
static char chr_1 = 'a';
static char chr_2 = 'b';

static void* producer(void* arg) {
    do {
        PRODUCER_PRE_ENQUEUE_WAIT_BLOCK(1);
        PRODUCER_PRE_ENQUEUE_WAIT_BLOCK(2);
        PRODUCER_PRE_ENQUEUE_WAIT_BLOCK(3);
        PRODUCER_PRE_ENQUEUE_WAIT_BLOCK(4);
        if (pthread_self() == producer_5_tid) {
            if (global_state == WAITING_4) {
                if (buf_ring_full(buf_ring)) {
                    __PRINTF_SYNC("Producer 5: Queue is full: flush it first\n");
                    pthread_mutex_unlock(&consumer_1_wait_mutex);
                    pthread_mutex_lock(&producer_5_wait_mutex);
                    __PRINTF_SYNC("Producer 5: prod_head = %d, cons_tail = %d\n", \
                            buf_ring->br_prod_head, buf_ring->br_cons_tail);
                    __PRINTF_SYNC("Producer 5: Launch attack!\n");     
                    LAUNCH_ATTACK;
                    global_state = OVERFLOW_READY;
                    __PRINTF_SYNC("Producer 5: All queue entries were written with 'a', none" \
                            " of them read\n");
                    __PRINTF_SYNC("Producer 5: The 'one entry always empty' invariant has" \
                            " been broken at this point\n");
                    __PRINTF_SYNC("Producer 5: Writing a 'b' would corrupt an unread entry\n");
                    buf_ring_enqueue(buf_ring, &chr_2);
                    global_state = EXIT;
                    UNLOCK_ALL_PRODUCERS;
                    pthread_mutex_unlock(&consumer_1_wait_mutex);
                    return NULL;
                }
            }
        }
        buf_ring_enqueue(buf_ring, &chr_1);
    } while (global_state != EXIT);
    return NULL;
}

static void* consumer(void* arg) {
    do {
        pthread_mutex_lock(&consumer_1_wait_mutex);
        chr_ptr = (char*)buf_ring_dequeue_mc(buf_ring);
        if (chr_ptr != NULL) {
            __PRINTF_SYNC("Consumer 1: Value retrieved = %c\n", *chr_ptr);
            pthread_mutex_unlock(&consumer_1_wait_mutex);
        } else {
            pthread_mutex_unlock(&producer_5_wait_mutex);  
            pthread_mutex_lock(&consumer_1_wait_mutex);
            pthread_mutex_unlock(&consumer_1_wait_mutex);
        }
    } while (global_state != EXIT);
    return NULL;
}

int main(void) {
    __PRINTF_SYNC("main: Start\n");
    int ret = 0;
    
    buf_ring = buf_ring_alloc(4, NULL, 0, NULL);
    if (buf_ring == NULL) {
        goto error;
    }

    if (pthread_mutex_init(&consumer_1_wait_mutex, NULL) != 0)
        goto error;
    if (pthread_mutex_init(&producer_1_wait_mutex, NULL) != 0)
        goto error;
    if (pthread_mutex_init(&producer_2_wait_mutex, NULL) != 0)
        goto error;
    if (pthread_mutex_init(&producer_3_wait_mutex, NULL) != 0)
        goto error;
    if (pthread_mutex_init(&producer_4_wait_mutex, NULL) != 0)
        goto error;
    if (pthread_mutex_init(&producer_5_wait_mutex, NULL) != 0)
        goto error;

    pthread_mutex_lock(&consumer_1_wait_mutex);
    pthread_mutex_lock(&producer_1_wait_mutex);
    pthread_mutex_lock(&producer_2_wait_mutex);
    pthread_mutex_lock(&producer_3_wait_mutex);
    pthread_mutex_lock(&producer_4_wait_mutex);
    pthread_mutex_lock(&producer_5_wait_mutex);

    global_state = WAITING_0;

    pthread_create(&producer_1_tid, NULL, producer, NULL);
    pthread_create(&producer_2_tid, NULL, producer, NULL);
    pthread_create(&producer_3_tid, NULL, producer, NULL);
    pthread_create(&producer_4_tid, NULL, producer, NULL);
    pthread_create(&producer_5_tid, NULL, producer, NULL);
    pthread_create(&consumer_1_tid, NULL, consumer, NULL);

    pthread_join(producer_1_tid, NULL);
    pthread_join(producer_2_tid, NULL);
    pthread_join(producer_3_tid, NULL);
    pthread_join(producer_4_tid, NULL);
    pthread_join(producer_5_tid, NULL);
    pthread_join(consumer_1_tid, NULL);

    __PRINTF_SYNC("main: Success\n");
    goto cleanup;
error:
    __PRINTF_SYNC("main: Error\n");
    ret = -1;
cleanup:
    if (buf_ring != NULL) {
        buf_ring_free(buf_ring, NULL);
    }    
    return ret;
}

struct buf_ring *
buf_ring_alloc(int count, struct malloc_type *type, int flags, struct mtx *lock)
{
	struct buf_ring *br;

	//KASSERT(powerof2(count), ("buf ring must be size power of 2"));
	
	br = (struct buf_ring *)calloc(1, sizeof(struct buf_ring) + count*sizeof(void*));
	if (br == NULL)
		return (NULL);
	br->br_prod_size = br->br_cons_size = count;
	br->br_prod_mask = br->br_cons_mask = count-1;
	br->br_prod_head = br->br_cons_head = 0;
	br->br_prod_tail = br->br_cons_tail = 0;
		
	return (br);
}

void
buf_ring_free(struct buf_ring *br, struct malloc_type *type)
{
	free(br);
}
