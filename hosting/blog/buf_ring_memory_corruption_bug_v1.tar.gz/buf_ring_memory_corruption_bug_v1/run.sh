#!/bin/bash

rm -rf bin
mkdir bin

gcc -std=gnu11 -Isrc -g -o bin/main src/main.c -lpthread

chmod +x bin/main

./bin/main
